CELLS_2 = []
M = lambda s: CELLS_2.append(("markdown", s))
C = lambda s: CELLS_2.append(("code", s))

M(r'''
## 3. Exploratory distributions

Before any testing, the distribution of each response variable is plotted by cultivar (box plot with every observation overlaid), so assumptions can be judged visually as well as numerically.
''')

C(r'''
fig, axes = plt.subplots(1, 4, figsize=(15, 3.8))
for ax, v in zip(axes, VARS):
    sns.boxplot(data=df, x="cultivar", y=v, order=CULT, palette=COLORS, width=0.55, fliersize=0, ax=ax, hue="cultivar", legend=False)
    sns.stripplot(data=df, x="cultivar", y=v, order=CULT, color="black", alpha=0.35, size=2.5, ax=ax)
    ax.set_title(v.replace("_", " ")); ax.set_xlabel(""); ax.tick_params(axis="x", labelrotation=15)
fig.suptitle("Figure 1. Distribution of each response by cultivar (box = quartiles, dots = wines)", y=1.04)
fig.tight_layout(); fig.savefig(FIG_DIR / "fig1_distributions_by_cultivar.png", dpi=150, bbox_inches="tight")
plt.show()
''')

M(r'''
## 4. Normality tests (Shapiro-Wilk and Kolmogorov-Smirnov)

**Why:** t-tests and ANOVA assume approximately normal data within groups (or residuals). Normality is therefore tested **within each cultivar** for each response variable.

**Hypotheses (for each of the 12 variable x cultivar samples):**

* **H0:** the sample comes from a normal distribution.
* **H1:** the sample does not come from a normal distribution.
* **Decision:** reject H0 if p < 0.05.

**Tests used**

1. **Shapiro-Wilk (W):** the most powerful general-purpose normality test at these sample sizes.
2. **Kolmogorov-Smirnov (D)** of the standardised sample against N(0,1). Because the mean and SD are *estimated from the same data*, the textbook KS p-value is too large (the test is conservative). Two p-values are therefore shown: the **plain KS** p (what `scipy.stats.kstest` returns) and the **Lilliefors-corrected KS** p, obtained from a 10,000-simulation null distribution of D with estimated parameters (validated in Section 2). The Lilliefors p is the one used for decisions.

Skewness and excess kurtosis are shown to explain *why* a sample fails.
''')

C(r'''
rows = []
for v in VARS:
    for c in CULT:
        x = df.loc[df.cultivar == c, v].to_numpy(float)
        W, p_sw = stats.shapiro(x); D, p_ks, p_lf = ks_normal(x)
        rows.append({"variable": v, "cultivar": c, "n": len(x), "skew": stats.skew(x), "excess_kurtosis": stats.kurtosis(x),
                     "SW_W": W, "SW_p": p_sw, "KS_D": D, "KS_p_plain": p_ks, "KS_p_lilliefors": p_lf,
                     "SW_normal": p_sw >= ALPHA, "KS_normal": p_lf >= ALPHA})
norm_df = pd.DataFrame(rows)
RESULTS["normality"] = norm_df.to_dict("records")
shown = norm_df.copy()
for col in ["skew", "excess_kurtosis", "SW_W", "KS_D"]: shown[col] = shown[col].round(3)
for col in ["SW_p", "KS_p_plain", "KS_p_lilliefors"]: shown[col] = shown[col].map(lambda p: "<0.001" if p < 0.001 else f"{p:.3f}")
shown["SW_normal"] = shown["SW_normal"].map({True: "normal", False: "reject"}); shown["KS_normal"] = shown["KS_normal"].map({True: "normal", False: "reject"})
display(Markdown("**Table 1. Normality tests within each cultivar (alpha = 0.05; decisions use the Lilliefors-corrected KS p).**"))
display(shown)
n_rej_sw, n_rej_ks = int((~norm_df.SW_normal).sum()), int((~norm_df.KS_normal).sum())
agree = int((norm_df.SW_normal == norm_df.KS_normal).sum())
display(Markdown(f"**Result:** Shapiro-Wilk rejects normality in **{n_rej_sw} of 12** samples and the Lilliefors-KS test in **{n_rej_ks} of 12**; "
                 f"the two tests give the same decision in **{agree} of 12** samples. The plain (uncorrected) KS test rejects in "
                 f"{int((norm_df.KS_p_plain < ALPHA).sum())} samples, illustrating its conservatism."))
''')

C(r'''
fig, axes = plt.subplots(4, 3, figsize=(12, 12))
for i, v in enumerate(VARS):
    for j, c in enumerate(CULT):
        ax = axes[i, j]; x = df.loc[df.cultivar == c, v].to_numpy(float)
        ax.hist(x, bins="auto", density=True, color=COLORS[c], alpha=0.45, edgecolor="white")
        sns.kdeplot(x, ax=ax, color=COLORS[c], lw=1.8)
        g = np.linspace(x.min() - x.std(), x.max() + x.std(), 200); ax.plot(g, stats.norm.pdf(g, x.mean(), x.std(ddof=1)), "k--", lw=1.2)
        r = norm_df[(norm_df.variable == v) & (norm_df.cultivar == c)].iloc[0]
        ax.set_title(f"{v.replace('_', ' ')} | {c}\nSW {fmt_p(r.SW_p)}, KS-L {fmt_p(r.KS_p_lilliefors)}", fontsize=9)
        ax.set_ylabel("density" if j == 0 else ""); ax.set_xlabel("")
fig.suptitle("Figure 2. Histogram + kernel density (solid) vs fitted normal curve (dashed)", y=1.0)
fig.tight_layout(); fig.savefig(FIG_DIR / "fig2_histograms_normal_fit.png", dpi=150, bbox_inches="tight")
plt.show()

fig, axes = plt.subplots(4, 3, figsize=(10, 12))
for i, v in enumerate(VARS):
    for j, c in enumerate(CULT):
        ax = axes[i, j]; x = df.loc[df.cultivar == c, v].to_numpy(float)
        (osm, osr), (slope, icpt, rr) = stats.probplot(x, dist="norm")
        ax.scatter(osm, osr, s=10, color=COLORS[c], alpha=0.7); ax.plot(osm, slope * osm + icpt, "k-", lw=1)
        ax.set_title(f"{v.replace('_', ' ')} | {c}  (r = {rr:.3f})", fontsize=9)
        ax.set_xlabel("theoretical quantiles" if i == 3 else ""); ax.set_ylabel("sample quantiles" if j == 0 else "")
fig.suptitle("Figure 3. Normal Q-Q plots (points on the line = normal)", y=1.0)
fig.tight_layout(); fig.savefig(FIG_DIR / "fig3_qq_plots.png", dpi=150, bbox_inches="tight")
plt.show()
''')

M(r'''
**Reading Section 4.** Where Shapiro-Wilk and the corrected KS test both reject, the histograms and Q-Q plots show the reason (long right tail or heavy tails, see skewness above), and the non-parametric tests in Sections 5 and 6 are the safer primary results. Where neither rejects, the parametric tests are well supported. With samples of 48 to 71 per group, the t-test and ANOVA are fairly robust to mild non-normality, which is why both families are always reported side by side.
''')

M(r'''
## 5. Two-sample tests: Student/Welch t-test and Mann-Whitney U

Two planned comparisons are made, both **Cultivar 1 vs Cultivar 2** (chosen in Section 1 before any testing):

| Comparison | Response | Reason for interest |
|---|---|---|
| A | `alcohol` | a roughly symmetric variable |
| B | `proline` | a right-skewed variable, where the t-test and the rank test may disagree |

**Hypotheses (identical form for A and B; mu = population mean, F = distribution function):**

* **t-test.** H0: mu(Cultivar 1) = mu(Cultivar 2). H1: mu(Cultivar 1) != mu(Cultivar 2). Both the **Student** (equal variances) and **Welch** (unequal variances) versions are run; the **95% CI** is for mu1 - mu2.
* **Mann-Whitney U.** H0: the two distributions are identical, equivalently P(X1 > X2) = 0.5. H1: one distribution is stochastically larger, P(X1 > X2) != 0.5. The **95% CI** is a bootstrap percentile interval (2,000 resamples) for the **Hodges-Lehmann shift**, the median of all pairwise differences.
* **Significance:** reject H0 if p < 0.05 (two-sided). Because two comparisons are planned, a **Bonferroni-adjusted p** (x 2) is also shown.

**Rule for the primary result (fixed in advance):** if Shapiro-Wilk does not reject normality in *both* groups, the **Welch t-test** is the primary result; otherwise the **Mann-Whitney U test** is. Equal-variance behaviour is checked with Levene's (median-centred) test, and Welch is preferred to Student whenever variances differ.

**Effect sizes:** Hedges' g (standardised mean difference, 95% CI), and for the rank test the rank-biserial correlation r = 2U/(n1 n2) - 1 and the common-language effect size P(X1 > X2) = U/(n1 n2).
''')

C(r'''
def compare_two(var, g1="Cultivar 1", g2="Cultivar 2", n_planned=2):
    a = df.loc[df.cultivar == g1, var].to_numpy(float); b = df.loc[df.cultivar == g2, var].to_numpy(float)
    sw = (stats.shapiro(a).pvalue, stats.shapiro(b).pvalue); lev = stats.levene(a, b, center="median")
    st = stats.ttest_ind(a, b, equal_var=True); we = stats.ttest_ind(a, b, equal_var=False)
    d_s, lo_s, hi_s, df_s = student_ci(a, b); d_w, lo_w, hi_w, df_w = welch_ci(a, b)
    assert np.isclose(st.pvalue, 2 * stats.t.sf(abs(st.statistic), df_s)) and np.isclose(we.df, df_w)
    mw = stats.mannwhitneyu(a, b, alternative="two-sided"); n1, n2 = len(a), len(b)
    rbc = 2 * mw.statistic / (n1 * n2) - 1; cles = mw.statistic / (n1 * n2)
    hl, hl_lo, hl_hi = hodges_lehmann(a, b, r=np.random.default_rng(SEED)); g, g_lo, g_hi = hedges_g_ci(a, b)
    tbl = pd.DataFrame([
        {"Test": "Student t (equal var.)", "Statistic": st.statistic, "df": df_s, "p": st.pvalue, "p_Bonferroni": min(1, st.pvalue * n_planned),
         "Estimate": d_s, "CI95_low": lo_s, "CI95_high": hi_s, "Estimate_meaning": "mean difference"},
        {"Test": "Welch t (unequal var.)", "Statistic": we.statistic, "df": df_w, "p": we.pvalue, "p_Bonferroni": min(1, we.pvalue * n_planned),
         "Estimate": d_w, "CI95_low": lo_w, "CI95_high": hi_w, "Estimate_meaning": "mean difference"},
        {"Test": "Mann-Whitney U", "Statistic": mw.statistic, "df": np.nan, "p": mw.pvalue, "p_Bonferroni": min(1, mw.pvalue * n_planned),
         "Estimate": hl, "CI95_low": hl_lo, "CI95_high": hl_hi, "Estimate_meaning": "Hodges-Lehmann shift"}])
    both_normal = sw[0] >= ALPHA and sw[1] >= ALPHA
    primary = "Welch t-test" if both_normal else "Mann-Whitney U"
    return {"var": var, "g1": g1, "g2": g2, "n": (n1, n2), "means": (a.mean(), b.mean()), "sds": (a.std(ddof=1), b.std(ddof=1)),
            "medians": (float(np.median(a)), float(np.median(b))), "shapiro_p": sw, "levene_p": lev.pvalue, "table": tbl,
            "hedges_g": (g, g_lo, g_hi), "rank_biserial": rbc, "cles": cles, "primary": primary,
            "primary_p": (we.pvalue if both_normal else mw.pvalue), "a": a, "b": b}

TWO = {v: compare_two(v) for v in ["alcohol", "proline"]}
for v, r in TWO.items():
    t = r["table"].copy()
    for col in ["Statistic", "df", "Estimate", "CI95_low", "CI95_high"]: t[col] = t[col].round(3)
    for col in ["p", "p_Bonferroni"]: t[col] = t[col].map(lambda p: "<0.001" if p < 0.001 else f"{p:.4f}")
    display(Markdown(f"### Comparison {'A' if v == 'alcohol' else 'B'}: `{v}`, {r['g1']} (n = {r['n'][0]}) vs {r['g2']} (n = {r['n'][1]})"))
    display(Markdown(f"Means {r['means'][0]:.2f} vs {r['means'][1]:.2f} (SD {r['sds'][0]:.2f} vs {r['sds'][1]:.2f}); medians {r['medians'][0]:.1f} vs {r['medians'][1]:.1f}. "
                     f"Shapiro-Wilk p = {r['shapiro_p'][0]:.3f} / {r['shapiro_p'][1]:.3f}; Levene (equal variances) {fmt_p(r['levene_p'])}."))
    display(t)
    g, gl, gh = r["hedges_g"]
    display(Markdown(f"Effect sizes: Hedges' g = **{g:.2f}** (95% CI {gl:.2f} to {gh:.2f}); rank-biserial r = **{r['rank_biserial']:.2f}**; "
                     f"P(Cultivar 1 > Cultivar 2) = **{r['cles']:.2f}**. By the pre-set rule the primary result is the **{r['primary']}** ({fmt_p(r['primary_p'])}) "
                     f"-> **{'reject H0' if r['primary_p'] < ALPHA else 'fail to reject H0'}** at alpha = 0.05."))
RESULTS["two_sample"] = {v: {k: (r[k] if k != "table" else r["table"].to_dict("records")) for k in
                             ["var", "g1", "g2", "n", "means", "sds", "medians", "shapiro_p", "levene_p", "table", "hedges_g", "rank_biserial", "cles", "primary", "primary_p"]}
                         for v, r in TWO.items()}
''')

C(r'''
fig, axes = plt.subplots(2, 2, figsize=(11, 7.5))
for row, (v, r) in enumerate(TWO.items()):
    a, b = r["a"], r["b"]; ax = axes[row, 0]
    bins = np.histogram_bin_edges(np.concatenate([a, b]), bins=20)
    ax.hist(a, bins=bins, alpha=0.55, color=COLORS[r["g1"]], label=f"{r['g1']} (mean {a.mean():.2f})", density=True)
    ax.hist(b, bins=bins, alpha=0.55, color=COLORS[r["g2"]], label=f"{r['g2']} (mean {b.mean():.2f})", density=True)
    ax.axvline(a.mean(), color=COLORS[r["g1"]], lw=2); ax.axvline(b.mean(), color=COLORS[r["g2"]], lw=2)
    ax.set_title(f"{v}: overlaid distributions"); ax.set_xlabel(v); ax.set_ylabel("density"); ax.legend(fontsize=8)
    ax = axes[row, 1]; t = r["table"]
    est = [t.loc[1, "Estimate"], t.loc[2, "Estimate"]]; lo = [t.loc[1, "CI95_low"], t.loc[2, "CI95_low"]]; hi = [t.loc[1, "CI95_high"], t.loc[2, "CI95_high"]]
    ax.errorbar(est, [1, 0], xerr=[np.array(est) - lo, np.array(hi) - est], fmt="o", color="black", capsize=5)
    ax.axvline(0, color="grey", ls="--"); ax.set_yticks([1, 0]); ax.set_yticklabels(["Welch t: mean difference", "Mann-Whitney: Hodges-Lehmann shift"])
    ax.set_title(f"{v}: estimated difference with 95% CI"); ax.set_xlabel("Cultivar 1 minus Cultivar 2"); ax.set_ylim(-0.6, 1.6)
fig.suptitle("Figure 4. Two-sample comparisons (Cultivar 1 vs Cultivar 2)", y=1.0)
fig.tight_layout(); fig.savefig(FIG_DIR / "fig4_two_sample_comparisons.png", dpi=150, bbox_inches="tight")
plt.show()
''')
