"""Fingerprint the plan. Run ONCE, after the data-blind check passes and before the confirmatory run."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from bmiprereg.lock import create_lock, verify_lock  # noqa: E402

if (ROOT / "PREREG_LOCK.json").exists():
    print("Already locked. To change the plan, record a deviation in preregistration.md instead of re-locking.")
    sys.exit(1)
lock = create_lock(ROOT, "Locked after data-blind synthetic pipeline check; before any outcome relationship was examined.")
print("Locked at", lock["locked_at_utc"])
for f, h in lock["files"].items():
    print(h[:16], f)
print(verify_lock(ROOT))
