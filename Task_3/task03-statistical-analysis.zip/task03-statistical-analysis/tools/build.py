import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from execute_nb import run
from cells_1 import CELLS_1
from cells_2 import CELLS_2
from cells_3 import CELLS_3
from cells_4 import CELLS_4
root = Path(__file__).resolve().parents[1]
run(CELLS_1 + CELLS_2 + CELLS_3 + CELLS_4, root / "notebooks" / "Task03_Statistical_Analysis.ipynb", root / "notebooks")
print("built")
