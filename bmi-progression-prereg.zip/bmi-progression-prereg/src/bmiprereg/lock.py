"""Pre-registration lock: SHA-256 fingerprints of every file that defines the analysis plan."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

LOCKED_FILES = [
    "preregistration.md",
    "config/analysis_config.json",
    "environment/requirements.lock",
    "contracts/output_contract.json",
    "src/bmiprereg/__init__.py",
    "src/bmiprereg/config.py",
    "src/bmiprereg/data.py",
    "src/bmiprereg/prepare.py",
    "src/bmiprereg/models.py",
    "src/bmiprereg/pipeline.py",
    "src/bmiprereg/contracts.py",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def create_lock(root: Path, extra_note: str = "") -> dict:
    root = Path(root)
    lock = {
        "locked_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "note": extra_note,
        "files": {f: sha256(root / f) for f in LOCKED_FILES},
    }
    (root / "PREREG_LOCK.json").write_text(json.dumps(lock, indent=2) + "\n", encoding="utf-8")
    return lock


def verify_lock(root: Path):
    """Return (ok, problems). Any changed/missing locked file is reported."""
    root = Path(root)
    lp = root / "PREREG_LOCK.json"
    if not lp.exists():
        return False, ["PREREG_LOCK.json not found - plan has not been locked"]
    lock = json.loads(lp.read_text(encoding="utf-8"))
    problems = []
    for f, h in lock["files"].items():
        p = root / f
        if not p.exists():
            problems.append(f"missing: {f}")
        elif sha256(p) != h:
            problems.append(f"modified after lock: {f}")
    return (not problems), problems
