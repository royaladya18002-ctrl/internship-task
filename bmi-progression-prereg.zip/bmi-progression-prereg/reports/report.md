---
title: "Task 02: Reproducible Research Question & Analysis Preregistration"
subtitle: "Baseline BMI and one-year disease progression in patients with diabetes"
date: "9 November 2026"
---

# 1. Assignment requirements and how each is met

The task brief (Task 02) says: *turn an interesting dataset into a falsifiable research question and lock the analysis plan before inspecting outcome patterns.* No separate PDF reached me; the requirements below come from the task screenshot and the attached preregistration template. No dataset was supplied, so I selected one that fits the brief (Section 2).

| # | Requirement from the brief | Where it is delivered | Status |
|---|---|---|---|
| 1 | Define the **population** | Section 3 (PICO table); `preregistration.md` | Done |
| 2 | Define the **exposure / intervention** | Section 3 | Done |
| 3 | Define the **comparator** | Section 3 | Done |
| 4 | Define the **outcome** | Section 3 | Done |
| 5 | Define the **observation window** | Section 3 (12 months, baseline to one year) | Done |
| 6 | Document **hypotheses** | Section 4 | Done |
| 7 | Document **exclusion rules** | Section 5 | Done |
| 8 | Document **transformations** | Section 6 | Done |
| 9 | Document **tests** | Section 7 | Done |
| 10 | Document **effect sizes** | Section 7 | Done |
| 11 | Document **robustness checks** | Section 7 (R1 to R8) | Done |
| 12 | Create a **reproducible environment lockfile** | `environment/requirements.lock` (Section 8) | Done |
| 13 | Create **raw, interim, processed, notebook and report structure** | `data/raw`, `data/interim`, `data/processed`, `notebooks/`, `reports/` (Section 8) | Done |
| 14 | Run a **data-blind pipeline check on synthetic fixtures** | 14 automated tests, all passing (Section 9) | Done |
| 15 | Record **expected output contracts** | `contracts/output_contract.json`, enforced in code (Section 10) | Done |
| 16 | Template section: **Research question** (one falsifiable question) | Section 3 | Done |
| 17 | Template section: **Population, sample, exclusions** incl. unit of analysis and stopping rule | Section 5 | Done |
| 18 | Template section: **Variables and measures** incl. controls and missing-data handling | Section 6 | Done |
| 19 | Template section: **Analysis plan** incl. assumptions, alpha, uncertainty intervals | Section 7 | Done |
| 20 | Template section: **Deviations** log with timestamp and reason | Section 11 | Done (empty at lock) |
| 21 | **Expected proof**: preregistration document | `preregistration.md` | Done |
| 22 | **Expected proof**: reproducible research repository | the `bmi-progression-prereg` folder (zip) | Done |
| 23 | **Expected proof**: environment lockfile | `environment/requirements.lock` | Done |
| 24 | **Expected proof**: synthetic pipeline test | `tests/` and `reports/synthetic_check_report.json` | Done |

# 2. Dataset choice

* **Dataset:** the Diabetes dataset of Efron, Hastie, Johnstone and Tibshirani (2004, *Annals of Statistics* 32(2), 407-499). It has 442 patient records with ten baseline variables (age, sex, BMI, mean blood pressure, six serum measures) and one outcome: a quantitative measure of disease progression one year after baseline.
* **Why it fits:** the one-year follow-up gives a natural observation window, the outcome is continuous, and the data ship inside scikit-learn, so the work is reproducible offline with `load_diabetes(scaled=False)` (raw units, so BMI and blood pressure are interpretable).
* **Outcome-blind audit before locking:** only row and column counts, predictor missingness and predictor ranges were examined (442 rows, 11 columns, no missing predictor values, no duplicates). No relationship between any predictor and the outcome was computed or viewed.

# 3. Research question and PICO

**Research question (falsifiable).** Among patients with diabetes, is a higher baseline BMI (top tertile) associated with a greater one-year disease-progression score than a lower baseline BMI (bottom tertile), after adjusting for age, sex and mean blood pressure?

| Element | Definition |
|---|---|
| Population | Adult patients with diabetes in the Efron et al. dataset (n = 442, ages 19 to 79) |
| Exposure | BMI at or above the upper sample tertile (66.67th percentile) |
| Comparator | BMI at or below the lower sample tertile (33.33rd percentile); middle tertile excluded from the primary contrast |
| Outcome | `target`: continuous one-year disease-progression score (higher means more progression) |
| Observation window | 12 months: exposure and covariates at baseline, outcome one year later |

# 4. Hypotheses

* **Null (H0):** after adjustment, mean one-year progression is equal in the high-BMI and low-BMI tertiles (exposure coefficient = 0).
* **Alternative (H1):** the adjusted means differ (two-sided test).
* **Expected direction:** positive (higher BMI, more progression), justified by the link between adiposity, insulin resistance and glycaemic control. The result counts as *supported* only if p < 0.05 **and** the estimate is positive. A significant negative estimate is reported as *contradicted*.
* **Multiplicity:** one confirmatory hypothesis, so no correction is needed. Robustness checks are sensitivity analyses, not extra significance claims.

# 5. Population, sample and exclusion rules

* **Unit of analysis:** one patient record.
* **Inclusion:** all records with non-missing BMI, age, sex, blood pressure and outcome.
* **Exclusion rules, applied in this order (each row counted under the first rule it fails):**
    1. Missing value in any required variable.
    2. Exact duplicate rows (first occurrence kept).
    3. Implausible values: BMI outside 10 to 70, age outside 18 to 100, outcome at or below 0.
    4. Primary contrast only: middle-tertile records are left out of the primary comparison (they stay in R1).
* **Stopping rule:** fixed sample. All 442 records are analysed once, with no interim looks and no optional stopping. Because the sample size is fixed, achieved precision (confidence-interval width) is reported instead of an a-priori power calculation.

# 6. Variables, transformations and missing data

| Role | Variable | Definition |
|---|---|---|
| Outcome | `target` | One-year progression score; untransformed in the primary model |
| Exposure | `bmi` | Indicator for top vs bottom sample tertile (cut-points from `numpy.quantile` at 1/3 and 2/3) |
| Control | `age` | Years, linear |
| Control | `sex` | Indicator for code 2 (the source does not document the coding, so no interpretation is assumed) |
| Control | `bp` | Mean blood pressure, linear |
| Sensitivity only | `s1` to `s6` | Serum measures; used only in R5 because they may be mediators of the BMI effect |

* **Transformations:** none in the primary model. R1 standardises BMI (z-score); R6 uses the natural log of the outcome.
* **Missing data:** complete-case analysis, no imputation; counts are reported under exclusion rule 1.

# 7. Analysis plan

* **Primary (confirmatory) model:** ordinary least squares on low- and high-tertile records: progression ~ intercept + high-BMI indicator + age + sex + blood pressure, with HC3 robust standard errors and t-based inference (n minus 5 degrees of freedom).
* **Alpha and intervals:** alpha = 0.05, two-sided; 95% confidence intervals.
* **Effect sizes:** adjusted mean difference (score units) and Hedges' g with an approximate 95% interval.
* **Assumption diagnostics (reported, never used to change the primary model):** Shapiro-Wilk for residual normality, Breusch-Pagan for heteroskedasticity (already handled by HC3), maximum VIF for multicollinearity, Cook's D above 4/n and maximum leverage for influence.

| ID | Robustness check | What it tests |
|---|---|---|
| R1 | Continuous BMI per 1 SD, full sample | Does the finding depend on tertile coding? |
| R2 | Welch t-test, unadjusted | Does it depend on covariate adjustment or equal variances? |
| R3 | Case-resampling bootstrap, B = 5000, percentile CI | Does it depend on t-based intervals? |
| R4 | Permutation test of the exposure label, B = 10000 | Does it depend on distributional assumptions? |
| R5 | Add serum covariates s1 to s6 | Sensitivity to extended adjustment (possible mediators) |
| R6 | Natural-log outcome | Sensitivity to outcome skew |
| R7 | WHO categories, BMI 30 or more vs under 25 | Sensitivity to the exposure definition (skipped if a group has fewer than 10 records) |
| R8 | Drop records with Cook's D above 4/n | Sensitivity to influential observations |

* **Decision rule:** the conclusion rests on the primary test alone. The result is called *robust* if every non-skipped check has the same sign as the primary estimate; any disagreement is reported in full and does not change the primary conclusion.

# 8. Reproducible repository and environment

```
bmi-progression-prereg/
  preregistration.md          locked plan
  PREREG_LOCK.json            SHA-256 fingerprints + UTC timestamp
  config/analysis_config.json seed, alpha, cut-offs, exclusions, resampling sizes
  environment/requirements.lock   exact version pins (Python 3.13.18)
  contracts/output_contract.json  expected output contract
  src/bmiprereg/              data, prepare, models, pipeline, contracts, lock
  tests/                      synthetic fixtures, 14 tests, golden file
  scripts/                    run_data_blind_check.py, lock_prereg.py, run_confirmatory.py
  data/raw  data/interim  data/processed
  notebooks/01_confirmatory_results.ipynb
  reports/                    this report, synthetic check report, figures/
  Makefile  README.md
```

* **Lockfile:** `requirements.lock` pins numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, scikit-learn 1.9.1, matplotlib 3.11.2, pytest 9.1.1 and their dependencies. `statsmodels` was not available in the environment, so all inference (HC3, Hedges' g, bootstrap, permutation, diagnostics) is implemented directly with numpy and scipy and cross-checked against independent reference code in the tests.
* **Determinism:** one master seed (20261109); all resampling uses a single seeded generator, so the same data, config and seed give byte-identical output.
* **Locking:** `PREREG_LOCK.json` stores SHA-256 hashes of the preregistration, config, lockfile, output contract and all pipeline code. The plan was also committed to git (commit `11cbba8`, tag `prereg-v1.0.0`). The confirmatory script refuses to run if any locked file has changed or if the synthetic check has not passed.
* **Folder flow:** raw data goes to `data/raw`, cleaned data to `data/interim`, results to `data/processed`, and the notebook and report read from there.

# 9. Data-blind pipeline check on synthetic fixtures

The pipeline was run on fully synthetic data with a known truth, so correctness was verified without looking at any real outcome. All 14 tests passed (check run recorded in `reports/synthetic_check_report.json`).

| Test | What it proves |
|---|---|
| Exclusion counts exact | A messy fixture with injected errors (5 missing BMI, 3 missing outcome, 2 BMI of 0, 1 age of 5, 2 negative outcomes, 4 duplicates) yields exactly 8 / 4 / 5 exclusions and 587 analysed rows |
| CI coverage of planted effect | Over 300 replications with a planted effect of 15, the 95% CI covered the truth between 90% and 99% of the time |
| Null false-positive rate | Over 300 null replications, p < 0.05 occurred 2% to 9% of the time (nominal 5%) |
| OLS matches independent reference | Coefficients match scikit-learn; HC3 standard errors match a brute-force loop implementation |
| Exposure assignment blind to outcome | The assignment function accepts only the BMI column; shuffling the outcome leaves groups unchanged |
| Deterministic and seed-sensitive | Same seed gives identical output; a different seed changes only the bootstrap and permutation results |
| Output contract satisfied | All sections and all eight robustness checks present and valid |
| Contract detects violations | NaN estimates, inverted CIs, unreconciled counts, missing checks and impossible p-values are all caught |
| Messy fixture passes the pipeline | Dirty input still produces a contract-valid result |
| WHO check skips safely | R7 is skipped, and flagged, when a group is too small |
| Planted effect recovered end to end | Planted effect of 20 recovered within 3 SE and judged *supported*; the null case brackets 0 |
| Golden-output regression | Seeded synthetic results match the stored values to 1e-8 |
| Real-data structure audit | 442 rows, 11 columns, no missing predictors; outcome relationships untouched |
| Lock detects tampering | Changing any locked file after locking is detected |

# 10. Expected output contract

Every pipeline result must satisfy (full version in `contracts/output_contract.json`):

* **Sections:** `meta`, `exclusions`, `primary`, `robustness` (R1 to R8), `diagnostics`, `decision`.
* **Reconciliation:** input rows minus missing, duplicate and implausible rows equals analysed rows; low + high + middle group sizes equal analysed rows; primary degrees of freedom equal the primary sample size minus 5.
* **Primary estimate:** all values finite, 0 ≤ p ≤ 1, CI brackets the estimate, standard error above 0, Hedges' g interval brackets g.
* **Robustness entries:** status is `ok` or `skipped_small_n`; every `ok` entry has a finite estimate and a CI, a p-value, or both.
* **Determinism:** identical input, config and seed give identical output.

# 11. Deviations log

| Timestamp (UTC) | Section | Change | Reason | Effect |
|---|---|---|---|---|
| None recorded at lock time (2026-11-09T04:58:55Z) | | | | |

# 12. Status, limitations and next steps

* **Where things stand:** the plan is locked and the pipeline is verified on synthetic data. The confirmatory analysis on the real outcome has deliberately **not** been run, because this task is about fixing the plan before outcome patterns are seen. Running `make confirm` does it in one step and writes `data/processed/results.json`.
* **Limitations of the design:** the data are observational, so even a significant result is an association, not a causal effect. The source documentation does not give the coding of `sex`. Tertile cut-points are sample-dependent. The dataset is a classic research dataset, so the findings do not generalise to a specific modern population.
* **Registration timestamp:** the lock and git tag are local. For an externally verifiable timestamp, upload `preregistration.md` and `PREREG_LOCK.json` to a registry such as OSF before running `make confirm`.
* **If you meant a different dataset:** the pipeline is driven by `config/analysis_config.json` and `src/bmiprereg/data.py`, so another dataset can be swapped in. Send the PDF or dataset name and I will redo the plan around it.
