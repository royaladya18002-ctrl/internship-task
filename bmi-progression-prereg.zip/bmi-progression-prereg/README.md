# Reproducible Research Question & Analysis Preregistration (Task 02)

**Question:** among patients with diabetes, is a higher baseline BMI (top tertile) associated with greater one-year disease progression than a lower BMI (bottom tertile), adjusting for age, sex and blood pressure?

## Layout
| Path | Purpose |
|---|---|
| `preregistration.md` | The preregistration (template sections + PICO) |
| `config/analysis_config.json` | Every analysis constant: seed, alpha, cut-offs, exclusions, resampling sizes |
| `environment/requirements.lock` | Exact package pins (reproducible environment) |
| `contracts/output_contract.json` | Expected output contract (enforced by `src/bmiprereg/contracts.py`) |
| `src/bmiprereg/` | Pipeline code (load, prepare, models, pipeline, contracts, lock) |
| `tests/` | Synthetic fixtures + 14 data-blind pipeline tests + golden regression file |
| `data/raw`, `data/interim`, `data/processed` | Raw -> cleaned -> results (filled only by the confirmatory run) |
| `notebooks/` | Results notebook (reads processed results only) |
| `reports/` | Assignment report, synthetic check report, figures |
| `PREREG_LOCK.json` | SHA-256 fingerprints + UTC timestamp of the locked plan |

## Workflow
```
make env      # build environment from the lockfile
make check    # data-blind pipeline check on synthetic fixtures (must pass)
make lock     # fingerprint the plan (once)
make confirm  # confirmatory analysis on the real data (refuses unless locked + check passed)
```
Any change to a locked file after locking is detected and blocks the confirmatory run; later changes go in the *Deviations* table with timestamp and reason.
