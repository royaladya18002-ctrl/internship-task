"""Statistical building blocks (numpy/scipy only; statsmodels is not installed in the locked environment)."""
import numpy as np
from scipy import stats


def ols_hc3(X, y, alpha=0.05):
    """OLS with HC3 heteroskedasticity-robust standard errors and t-based inference."""
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    n, k = X.shape
    if np.linalg.matrix_rank(X) < k:
        raise np.linalg.LinAlgError("Design matrix is rank deficient")
    xtx_inv = np.linalg.inv(X.T @ X)
    beta = xtx_inv @ X.T @ y
    resid = y - X @ beta
    h = np.einsum("ij,jk,ik->i", X, xtx_inv, X)
    w = (resid / (1.0 - h)) ** 2
    cov = xtx_inv @ (X.T * w) @ X @ xtx_inv
    se = np.sqrt(np.diag(cov))
    df = n - k
    t = beta / se
    p = 2 * stats.t.sf(np.abs(t), df)
    crit = stats.t.ppf(1 - alpha / 2, df)
    s2 = float(resid @ resid) / df
    cooks = resid**2 / (k * s2) * h / (1 - h) ** 2
    return {
        "beta": beta, "se": se, "t": t, "p": p, "df": int(df),
        "ci_low": beta - crit * se, "ci_high": beta + crit * se,
        "resid": resid, "leverage": h, "cooks": cooks, "n": int(n), "k": int(k),
    }


def hedges_g(y_high, y_low, alpha=0.05):
    """Standardised mean difference (high - low), small-sample corrected, with approximate CI."""
    a, b = np.asarray(y_high, float), np.asarray(y_low, float)
    n1, n2 = len(a), len(b)
    sp = np.sqrt(((n1 - 1) * a.var(ddof=1) + (n2 - 1) * b.var(ddof=1)) / (n1 + n2 - 2))
    d = (a.mean() - b.mean()) / sp
    j = 1 - 3 / (4 * (n1 + n2) - 9)
    g = d * j
    se = np.sqrt((n1 + n2) / (n1 * n2) + g**2 / (2 * (n1 + n2)))
    z = stats.norm.ppf(1 - alpha / 2)
    return float(g), float(g - z * se), float(g + z * se)


def breusch_pagan_p(X, resid):
    X = np.asarray(X, float)
    e2 = np.asarray(resid, float) ** 2
    coef, *_ = np.linalg.lstsq(X, e2, rcond=None)
    fitted = X @ coef
    ss_tot = float(((e2 - e2.mean()) ** 2).sum())
    r2 = 0.0 if ss_tot == 0 else 1 - float(((e2 - fitted) ** 2).sum()) / ss_tot
    lm = len(e2) * r2
    return float(stats.chi2.sf(lm, X.shape[1] - 1))


def max_vif(X_no_intercept):
    Z = np.asarray(X_no_intercept, float)
    if Z.shape[1] < 2:
        return 1.0
    corr = np.corrcoef(Z, rowvar=False)
    return float(np.max(np.diag(np.linalg.inv(corr))))


def bootstrap_coef(X, y, j, B, rng, alpha=0.05):
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    n = len(y)
    est = np.empty(B)
    for b in range(B):
        idx = rng.integers(0, n, n)
        coef, *_ = np.linalg.lstsq(X[idx], y[idx], rcond=None)
        est[b] = coef[j]
    lo, hi = np.quantile(est, [alpha / 2, 1 - alpha / 2])
    return float(lo), float(hi)


def permutation_p(X, y, j, B, rng):
    X = np.asarray(X, float).copy()
    y = np.asarray(y, float)
    obs, *_ = np.linalg.lstsq(X, y, rcond=None)
    obs = obs[j]
    col = X[:, j].copy()
    hits = 0
    for _ in range(B):
        X[:, j] = rng.permutation(col)
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        hits += abs(coef[j]) >= abs(obs) - 1e-12
    return float((1 + hits) / (B + 1))
