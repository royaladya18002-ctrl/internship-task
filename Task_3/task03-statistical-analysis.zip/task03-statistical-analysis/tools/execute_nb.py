"""Minimal notebook builder/executor (nbformat v4.5 JSON) used because Jupyter is not installed here.
Executes every code cell in one shared namespace, captures stdout, rich displays and matplotlib figures,
and writes a valid .ipynb that opens in Jupyter/VS Code/Colab with outputs already embedded."""
import ast, base64, contextlib, io, json, sys, types, uuid, platform
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


class Markdown:
    def __init__(self, data): self.data = data
    def _out(self): return {"text/markdown": self.data, "text/plain": self.data}


class HTML:
    def __init__(self, data): self.data = data
    def _out(self): return {"text/html": self.data, "text/plain": "<HTML>"}


def _lines(s):
    return s.splitlines(True)


def run(cells, out_path, cwd):
    outs = []
    buf = io.StringIO()

    def flush():
        if buf.getvalue():
            outs.append({"output_type": "stream", "name": "stdout", "text": _lines(buf.getvalue())})
            buf.seek(0); buf.truncate()

    def bundle(obj):
        if isinstance(obj, (Markdown, HTML)):
            return obj._out()
        if isinstance(obj, pd.DataFrame):
            return {"text/html": obj.to_html(), "text/plain": repr(obj)}
        if isinstance(obj, pd.io.formats.style.Styler):
            return {"text/html": obj.to_html(), "text/plain": repr(obj.data)}
        return {"text/plain": repr(obj)}

    def display(*objs):
        for o in objs:
            flush()
            d = bundle(o)
            outs.append({"output_type": "display_data", "data": {k: _lines(v) if isinstance(v, str) else v for k, v in d.items()}, "metadata": {}})

    def show(*a, **k):
        flush()
        for num in plt.get_fignums():
            fig = plt.figure(num)
            b = io.BytesIO()
            fig.savefig(b, format="png", dpi=110, bbox_inches="tight")
            outs.append({"output_type": "display_data", "metadata": {},
                         "data": {"image/png": base64.b64encode(b.getvalue()).decode(), "text/plain": ["<Figure>"]}})
        plt.close("all")

    plt.show = show
    # IPython is not installed: the notebook keeps its normal `from IPython.display import ...` line, but for
    # execution here that one import is replaced by the equivalent objects defined in this module.
    ns = {"__name__": "__main__", "display": display, "Markdown": Markdown, "HTML": HTML}
    import os
    os.chdir(cwd)
    nb_cells, count = [], 0
    for kind, src in cells:
        cid = uuid.uuid4().hex[:8]
        if kind == "markdown":
            nb_cells.append({"cell_type": "markdown", "id": cid, "metadata": {}, "source": _lines(src.strip("\n"))})
            continue
        count += 1
        outs.clear(); buf.seek(0); buf.truncate()
        tree = ast.parse(src.replace("from IPython.display import display, Markdown", "pass"))
        last = None
        if tree.body and isinstance(tree.body[-1], ast.Expr):
            last = ast.Expression(tree.body.pop().value)
        val = None
        with contextlib.redirect_stdout(buf):
            exec(compile(tree, f"<cell {count}>", "exec"), ns)
            if last is not None:
                val = eval(compile(last, f"<cell {count}>", "eval"), ns)
        flush()
        show() if plt.get_fignums() else None
        if val is not None:
            d = bundle(val)
            outs.append({"output_type": "execute_result", "execution_count": count, "metadata": {},
                         "data": {k: _lines(v) if isinstance(v, str) else v for k, v in d.items()}})
        nb_cells.append({"cell_type": "code", "id": cid, "metadata": {}, "execution_count": count,
                         "source": _lines(src.strip("\n")), "outputs": list(outs)})
    nb = {"cells": nb_cells, "nbformat": 4, "nbformat_minor": 5,
          "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                       "language_info": {"name": "python", "version": platform.python_version()}}}
    Path(out_path).write_text(json.dumps(nb, indent=1), encoding="utf-8")
    return ns
