"""Synthetic fixtures for the DATA-BLIND pipeline check. No real outcome values are used anywhere here."""
import numpy as np
import pandas as pd

MEANS = {"s1": 189.1, "s2": 115.4, "s3": 49.8, "s4": 4.07, "s5": 4.64, "s6": 91.3}
SDS = {"s1": 34.6, "s2": 30.4, "s3": 12.9, "s4": 1.29, "s5": 0.52, "s6": 11.5}


def make_synthetic(n=600, delta=0.0, seed=1, noise_sd=45.0, messy=False):
    """Outcome = 150 + delta * 1[bmi in top tertile] + small covariate effects + noise.
    With delta=0 the outcome is unrelated to BMI (true null); with delta>0 the planted effect is known."""
    rng = np.random.default_rng(seed)
    d = pd.DataFrame({
        "age": rng.integers(19, 80, n).astype(float),
        "sex": rng.choice([1.0, 2.0], n),
        "bmi": np.clip(rng.normal(26.4, 4.4, n), 18, 42.2).round(1),
        "bp": rng.normal(94.6, 13.8, n).round(0),
    })
    for k in MEANS:
        d[k] = rng.normal(MEANS[k], SDS[k], n)
    q_hi = np.quantile(d["bmi"], 2 / 3)
    d["target"] = (150 + delta * (d["bmi"] >= q_hi) + 0.3 * (d["age"] - 48) + 4 * (d["sex"] == 2)
                   + 0.5 * (d["bp"] - 95) + rng.normal(0, noise_sd, n)).clip(lower=25).round(0)
    if messy:
        d = d.copy()
        d.loc[0:4, "bmi"] = np.nan          # 5 missing exposure
        d.loc[5:7, "target"] = np.nan       # 3 missing outcome
        d.loc[8:9, "bmi"] = 0.0             # 2 implausible BMI
        d.loc[10, "age"] = 5.0              # 1 implausible age
        d.loc[11:12, "target"] = -3.0       # 2 non-positive outcome
        d = pd.concat([d, d.iloc[100:104]], ignore_index=True)  # 4 exact duplicates of clean rows
    return d
