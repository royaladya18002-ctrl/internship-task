# Environment

* `requirements.lock` - exact version pins of every package the pipeline, tests and figures need.
* Interpreter: CPython 3.13.18 (recorded in `PREREG_LOCK.json` through the hash of this file and in each result's `meta`).
* `requirements.lock` is part of the locked plan: changing it after locking breaks the lock check.
* Seeds: one master seed (`20261109`) in `config/analysis_config.json`; all resampling uses `numpy.random.default_rng(seed)`.
