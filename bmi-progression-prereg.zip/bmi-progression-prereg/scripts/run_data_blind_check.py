"""Run the data-blind pipeline check on synthetic fixtures and write reports/synthetic_check_report.json."""
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
junit = ROOT / "reports" / "synthetic_check_junit.xml"
proc = subprocess.run([sys.executable, "-m", "pytest", "-q", "--junitxml", str(junit)], cwd=ROOT,
                      capture_output=True, text=True)
print(proc.stdout[-1500:])
import xml.etree.ElementTree as ET
suite = ET.parse(junit).getroot()
suite = suite if suite.tag == "testsuite" else suite[0]
tests = [{"name": tc.get("name"), "passed": len(list(tc)) == 0} for tc in suite.iter("testcase")]
report = {
    "checked_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "passed": proc.returncode == 0,
    "n_tests": len(tests),
    "n_failed": sum(not t["passed"] for t in tests),
    "tests": tests,
}
(ROOT / "reports" / "synthetic_check_report.json").write_text(json.dumps(report, indent=2) + "\n")
sys.exit(proc.returncode)
