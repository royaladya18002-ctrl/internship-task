CELLS_3 = []
M = lambda s: CELLS_3.append(("markdown", s))
C = lambda s: CELLS_3.append(("code", s))

M(r'''
## 6. One-Way ANOVA with Tukey HSD post-hoc analysis

**Question:** does mean `proline` concentration differ across the three cultivars? (`proline` was chosen in Section 1 because it is right-skewed, so the robustness of the conclusion matters.)

**Hypotheses**

* **H0:** mu(Cultivar 1) = mu(Cultivar 2) = mu(Cultivar 3) (all three population means are equal).
* **H1:** at least one cultivar mean differs from the others.
* **Decision:** reject H0 if the F-test p < 0.05.

**Assumptions checked in 6.2:** independence (separate wines), normality of residuals (Shapiro-Wilk, Q-Q), equal variances (Levene). If equal variances are rejected, the **Welch ANOVA** is the more trustworthy omnibus test, and the non-parametric **Kruskal-Wallis** test is run as a distribution-free check.

**Post-hoc (Section 6.4):** if H0 is rejected, **Tukey HSD** tests every pair (H0: mu_i = mu_j) with the family-wise error held at 5%, and gives simultaneous **95% CIs** for each mean difference. Because Tukey assumes equal variances, the **Games-Howell** procedure (valid under unequal variances) and Holm-adjusted pairwise Mann-Whitney tests are shown as robustness checks.
''')

C(r'''
groups = [df.loc[df.cultivar == c, "proline"].to_numpy(float) for c in CULT]
ow = anova_oneway(groups); assert np.isclose(ow["p"], stats.f_oneway(*groups).pvalue)
tcrit = lambda n: stats.t.ppf(1 - ALPHA / 2, n - 1)
desc = pd.DataFrame({"cultivar": CULT, "n": [len(g) for g in groups], "mean": [g.mean() for g in groups], "SD": [g.std(ddof=1) for g in groups],
                     "mean_CI95_low": [g.mean() - tcrit(len(g)) * g.std(ddof=1) / math.sqrt(len(g)) for g in groups],
                     "mean_CI95_high": [g.mean() + tcrit(len(g)) * g.std(ddof=1) / math.sqrt(len(g)) for g in groups]}).round(1)
display(Markdown("**Table 3. Proline by cultivar with 95% CI for each mean.**")); display(desc)

anova_tbl = pd.DataFrame([{"Source": "Between cultivars", "SS": ow["ssb"], "df": ow["dfb"], "MS": ow["msb"], "F": ow["F"], "p": ow["p"]},
                          {"Source": "Within (residual)", "SS": ow["ssw"], "df": ow["dfw"], "MS": ow["msw"], "F": np.nan, "p": np.nan},
                          {"Source": "Total", "SS": ow["sst"], "df": ow["dfb"] + ow["dfw"], "MS": np.nan, "F": np.nan, "p": np.nan}])
display(Markdown("**Table 4. One-way ANOVA table.**")); display(anova_tbl.round(4))
display(Markdown(f"**F({ow['dfb']}, {ow['dfw']}) = {ow['F']:.2f}, {fmt_p(ow['p'])}**; effect sizes: eta-squared = **{ow['eta2']:.3f}**, omega-squared = **{ow['omega2']:.3f}** "
                 f"(share of proline variance associated with cultivar). Decision: **{'reject H0' if ow['p'] < ALPHA else 'fail to reject H0'}** at alpha = 0.05."))
''')

M(r'''
### 6.2 Assumption checks for the one-way model
''')

C(r'''
resid_ow = np.concatenate([g - g.mean() for g in groups])
sw_ow = stats.shapiro(resid_ow); lev_ow = stats.levene(*groups, center="median")
F_w, d1_w, d2_w, p_w = welch_anova(groups); kw = stats.kruskal(*groups)
eps2 = (kw.statistic - len(groups) + 1) / (len(resid_ow) - len(groups))     # epsilon-squared effect size for Kruskal-Wallis
chk = pd.DataFrame([
    {"Check": "Residual normality (Shapiro-Wilk)", "Statistic": sw_ow.statistic, "p": sw_ow.pvalue, "Reading": "normality " + ("not rejected" if sw_ow.pvalue >= ALPHA else "rejected")},
    {"Check": "Equal variances (Levene, median-centred)", "Statistic": lev_ow.statistic, "p": lev_ow.pvalue, "Reading": "equal variances " + ("not rejected" if lev_ow.pvalue >= ALPHA else "rejected")},
    {"Check": f"Welch ANOVA  F({d1_w}, {d2_w:.1f})", "Statistic": F_w, "p": p_w, "Reading": "groups differ" if p_w < ALPHA else "no difference"},
    {"Check": f"Kruskal-Wallis  H({len(groups) - 1})", "Statistic": kw.statistic, "p": kw.pvalue, "Reading": "groups differ" if kw.pvalue < ALPHA else "no difference"}])
chk["Statistic"] = chk["Statistic"].round(3); chk["p"] = chk["p"].map(lambda p: "<0.001" if p < 0.001 else f"{p:.4f}")
display(Markdown("**Table 5. Assumption checks and assumption-light alternatives to the omnibus F-test.**")); display(chk)
display(Markdown(f"Kruskal-Wallis effect size epsilon-squared = **{eps2:.3f}**. All three omnibus tests (classical F, Welch F, Kruskal-Wallis) "
                 f"{'agree' if (ow['p'] < ALPHA) == (p_w < ALPHA) == (kw.pvalue < ALPHA) else 'do NOT agree'} on whether the cultivars differ."))

fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))
for g, c in zip(groups, CULT): sns.kdeplot(g, ax=axes[0], color=COLORS[c], fill=True, alpha=0.25, lw=1.8, label=c)
axes[0].set_title("Proline distribution by cultivar"); axes[0].set_xlabel("proline"); axes[0].legend(fontsize=8)
(osm, osr), (sl, ic, rr) = stats.probplot(resid_ow, dist="norm"); axes[1].scatter(osm, osr, s=10, alpha=0.6, color="#444"); axes[1].plot(osm, sl * osm + ic, "r-")
axes[1].set_title(f"Q-Q plot of ANOVA residuals (r = {rr:.3f})"); axes[1].set_xlabel("theoretical quantiles"); axes[1].set_ylabel("residuals")
fitted = np.concatenate([np.full(len(g), g.mean()) for g in groups]); axes[2].scatter(fitted, resid_ow, s=10, alpha=0.6, color="#444"); axes[2].axhline(0, color="r")
axes[2].set_title("Residuals vs fitted (spread = equal-variance check)"); axes[2].set_xlabel("fitted (group mean)"); axes[2].set_ylabel("residual")
fig.suptitle("Figure 5. One-way ANOVA diagnostics", y=1.03); fig.tight_layout(); fig.savefig(FIG_DIR / "fig5_oneway_diagnostics.png", dpi=150, bbox_inches="tight")
plt.show()
''')

M(r'''
### 6.4 Tukey HSD post-hoc comparisons

**Hypotheses for each pair (i, j):** H0: mu_i = mu_j versus H1: mu_i != mu_j, tested at a family-wise error rate of 5% across the three pairs. The difference is mean_i minus mean_j; the CI is the simultaneous 95% Tukey interval (an interval that excludes 0 is equivalent to p_adj < 0.05).
''')

C(r'''
tk = tukey_table(groups, CULT); gh = games_howell(groups, CULT)
mw_pairs = []
for i in range(3):
    for j in range(i + 1, 3):
        mw_pairs.append({"comparison": f"{CULT[i]} - {CULT[j]}", "p_raw": stats.mannwhitneyu(groups[i], groups[j], alternative="two-sided").pvalue})
mw_pairs = pd.DataFrame(mw_pairs); mw_pairs["p_Holm"] = holm(mw_pairs.p_raw)
post = tk.merge(gh[["comparison", "p"]].rename(columns={"p": "p_GamesHowell"}), on="comparison").merge(mw_pairs[["comparison", "p_Holm"]].rename(columns={"p_Holm": "p_MWU_Holm"}), on="comparison")
RESULTS["oneway"] = {"F": ow["F"], "dfb": ow["dfb"], "dfw": ow["dfw"], "p": ow["p"], "eta2": ow["eta2"], "omega2": ow["omega2"], "welch_F": F_w, "welch_p": p_w,
                     "kruskal_H": kw.statistic, "kruskal_p": kw.pvalue, "levene_p": lev_ow.pvalue, "shapiro_resid_p": sw_ow.pvalue,
                     "means": dict(zip(CULT, [g.mean() for g in groups])), "tukey": post.to_dict("records")}
shown = post.copy()
for col in ["diff", "ci_low", "ci_high"]: shown[col] = shown[col].round(1)
for col in ["p_adj", "p_GamesHowell", "p_MWU_Holm"]: shown[col] = shown[col].map(lambda p: "<0.001" if p < 0.001 else f"{p:.4f}")
display(Markdown("**Table 6. Tukey HSD (mean difference in proline, simultaneous 95% CI) with two robustness checks.**")); display(shown)
sig_pairs = [r.comparison for r in post.itertuples() if r.significant]
display(Markdown(f"**Tukey HSD:** {len(sig_pairs)} of 3 pairs differ significantly ({'; '.join(sig_pairs) if sig_pairs else 'none'}). "
                 f"Games-Howell reaches the same decisions for all pairs: **{bool(((post.p_GamesHowell < ALPHA) == post.significant).all())}**; "
                 f"Holm-adjusted Mann-Whitney does as well: **{bool(((post.p_MWU_Holm < ALPHA) == post.significant).all())}**."))

fig, ax = plt.subplots(figsize=(8.5, 3.6)); ypos = np.arange(len(post))[::-1]
ax.errorbar(post["diff"], ypos, xerr=[post["diff"] - post["ci_low"], post["ci_high"] - post["diff"]], fmt="o", color="black", capsize=5)
ax.axvline(0, color="grey", ls="--"); ax.set_yticks(ypos); ax.set_yticklabels(post["comparison"])
ax.set_xlabel("difference in mean proline (simultaneous 95% Tukey CI)"); ax.set_title("Figure 6. Tukey HSD pairwise differences")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig6_tukey_oneway.png", dpi=150, bbox_inches="tight")
plt.show()
''')

M(r'''
## 7. Two-Way ANOVA (with interaction) and Tukey HSD

**Question:** does `flavanoids` content depend on **cultivar** (3 levels), on **magnesium level** (Low vs High, split at the sample median), or on their **combination**? (`flavanoids` and the magnesium split were fixed in Section 1.)

**Model:** flavanoids = grand mean + cultivar effect + magnesium effect + cultivar x magnesium interaction + error. The design is **unbalanced** (cells hold 16 to 52 wines), so **Type III sums of squares** with sum-to-zero (effect) coding are the primary table, and Type II is shown for comparison. Both were validated against closed-form sums of squares in Section 2.

**Three pairs of hypotheses (each tested at alpha = 0.05):**

| Effect | H0 | H1 |
|---|---|---|
| Cultivar (main effect) | all three cultivar means are equal (averaged over magnesium levels) | at least one cultivar mean differs |
| Magnesium level (main effect) | Low-Mg and High-Mg means are equal (averaged over cultivars) | the two means differ |
| Cultivar x Magnesium (interaction) | the magnesium effect is the same in every cultivar (no interaction) | the magnesium effect differs between cultivars |

Because an interaction changes how main effects should be read, the interaction is interpreted **first**. If it is significant, simple effects (magnesium effect within each cultivar, Bonferroni-adjusted over 3 tests) are reported. Assumptions: independence, normal residuals (Shapiro-Wilk, Q-Q) and equal cell variances (Levene). A **rank-transformed ANOVA** is the distribution-free robustness check. Tukey HSD is then applied to all 6 cell means (15 pairs).
''')

C(r'''
med_mg = df["magnesium"].median()
df["mg_level"] = np.where(df["magnesium"] > med_mg, "High Mg", "Low Mg")
MG = ["Low Mg", "High Mg"]
print(f"Median magnesium = {med_mg:.0f}; Low Mg = at or below the median, High Mg = above it.")
cellcount = pd.crosstab(df.cultivar, df.mg_level).reindex(index=CULT, columns=MG)
display(Markdown("**Table 7. Design: number of wines in each cultivar x magnesium cell (unbalanced).**")); display(cellcount)

res2 = anova2(df, "flavanoids", "cultivar", "mg_level", CULT, MG); t3, t2 = res2["type3"].copy(), res2["type2"].copy()
def fmt_anova(t):
    t = t.copy(); t["p"] = t["p"].map(lambda p: "" if pd.isna(p) else ("<0.001" if p < 0.001 else f"{p:.4f}"))
    for c_ in ["SS", "MS", "F", "partial_eta2"]: t[c_] = t[c_].round(3)
    return t.fillna("")
display(Markdown("**Table 8. Two-way ANOVA, Type III sums of squares (primary).**")); display(fmt_anova(t3))
display(Markdown("**Table 9. Two-way ANOVA, Type II sums of squares (comparison).**")); display(fmt_anova(t2))
ranked = df.assign(rank_flav=stats.rankdata(df["flavanoids"])); rk = anova2(ranked, "rank_flav", "cultivar", "mg_level", CULT, MG)["type3"]
display(Markdown("**Table 10. Robustness: Type III ANOVA on the ranks of flavanoids (non-parametric check).**")); display(fmt_anova(rk))

def line(t, name):
    r = t.set_index("Source").loc[name]; return f"F({int(r['df'])}, {int(t.set_index('Source').loc['Residual','df'])}) = {r['F']:.2f}, {fmt_p(r['p'])}, partial eta-squared = {r['partial_eta2']:.3f}"
src_int = "cultivar x mg_level"
display(Markdown(f"**Cultivar:** {line(t3, 'cultivar')} -> **{'reject H0' if t3.set_index('Source').loc['cultivar','p'] < ALPHA else 'fail to reject H0'}**.  \n"
                 f"**Magnesium level:** {line(t3, 'mg_level')} -> **{'reject H0' if t3.set_index('Source').loc['mg_level','p'] < ALPHA else 'fail to reject H0'}**.  \n"
                 f"**Interaction:** {line(t3, src_int)} -> **{'reject H0' if t3.set_index('Source').loc[src_int,'p'] < ALPHA else 'fail to reject H0'}**."))
RESULTS["twoway"] = {"cell_counts": cellcount.to_dict(), "type3": res2["type3"].to_dict("records"), "type2": res2["type2"].to_dict("records"), "rank_type3": rk.to_dict("records")}
''')

C(r'''
cells_ = df.groupby(["cultivar", "mg_level"])["flavanoids"].agg(["count", "mean", "std"]).reindex(pd.MultiIndex.from_product([CULT, MG])).reset_index()
cells_.columns = ["cultivar", "mg_level", "n", "mean", "SD"]
cells_["CI95_low"] = cells_["mean"] - stats.t.ppf(0.975, cells_.n - 1) * cells_.SD / np.sqrt(cells_.n)
cells_["CI95_high"] = cells_["mean"] + stats.t.ppf(0.975, cells_.n - 1) * cells_.SD / np.sqrt(cells_.n)
display(Markdown("**Table 11. Cell means of flavanoids with 95% CI.**")); display(cells_.round(3))

resid2 = res2["resid"]; cell_groups = [df.loc[(df.cultivar == c) & (df.mg_level == m), "flavanoids"].to_numpy(float) for c in CULT for m in MG]
sw2 = stats.shapiro(resid2); lev2 = stats.levene(*cell_groups, center="median")
display(Markdown(f"**Assumptions:** residual normality Shapiro-Wilk W = {sw2.statistic:.3f}, {fmt_p(sw2.pvalue)}; equal cell variances Levene W = {lev2.statistic:.2f}, {fmt_p(lev2.pvalue)}. "
                 f"The rank-based ANOVA (Table 10) {'agrees' if all((rk.set_index('Source').loc[s, 'p'] < ALPHA) == (t3.set_index('Source').loc[s, 'p'] < ALPHA) for s in ['cultivar', 'mg_level', src_int]) else 'does NOT agree'} with the classical decisions for all three effects."))
RESULTS["twoway"].update({"shapiro_resid_p": sw2.pvalue, "levene_p": lev2.pvalue, "cells": cells_.to_dict("records")})

fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
for m, mk, ls in zip(MG, ["o", "s"], ["-", "--"]):
    s = cells_[cells_.mg_level == m]; x = np.arange(3) + (0.04 if m == "High Mg" else -0.04)
    axes[0].errorbar(x, s["mean"], yerr=[s["mean"] - s.CI95_low, s.CI95_high - s["mean"]], marker=mk, ls=ls, capsize=4, label=m, lw=1.8)
axes[0].set_xticks(range(3)); axes[0].set_xticklabels(CULT); axes[0].set_ylabel("mean flavanoids (95% CI)"); axes[0].legend(title="magnesium")
axes[0].set_title("Interaction plot (non-parallel lines = interaction)")
sns.boxplot(data=df, x="cultivar", y="flavanoids", hue="mg_level", order=CULT, hue_order=MG, ax=axes[1], palette=["#9ecae1", "#3182bd"], fliersize=2)
axes[1].set_title("Flavanoids by cultivar x magnesium level"); axes[1].set_xlabel(""); axes[1].legend(title="magnesium", fontsize=8)
(osm, osr), (sl, ic, rr) = stats.probplot(resid2, dist="norm"); axes[2].scatter(osm, osr, s=10, alpha=0.6, color="#444"); axes[2].plot(osm, sl * osm + ic, "r-")
axes[2].set_title(f"Q-Q plot of two-way ANOVA residuals (r = {rr:.3f})"); axes[2].set_xlabel("theoretical quantiles"); axes[2].set_ylabel("residuals")
fig.suptitle("Figure 7. Two-way ANOVA: cell means, distributions and residual check", y=1.03)
fig.tight_layout(); fig.savefig(FIG_DIR / "fig7_twoway_anova.png", dpi=150, bbox_inches="tight")
plt.show()
''')

M(r'''
### 7.4 Simple effects of magnesium within each cultivar
Reported to interpret the interaction. For each cultivar: H0: mean(High Mg) = mean(Low Mg) versus H1: they differ (Welch t-test, 95% CI for High minus Low, Bonferroni-adjusted over the 3 tests).

### 7.5 Tukey HSD across the six cultivar x magnesium cells
For each pair of cells: H0: the two cell means are equal; simultaneous 95% CIs control the family-wise error over all 15 pairs.
''')

C(r'''
se_rows = []
for c in CULT:
    hi_ = df.loc[(df.cultivar == c) & (df.mg_level == "High Mg"), "flavanoids"].to_numpy(float); lo_ = df.loc[(df.cultivar == c) & (df.mg_level == "Low Mg"), "flavanoids"].to_numpy(float)
    d_, l_, u_, df_ = welch_ci(hi_, lo_); tt = stats.ttest_ind(hi_, lo_, equal_var=False)
    se_rows.append({"cultivar": c, "n_High": len(hi_), "n_Low": len(lo_), "High_minus_Low": d_, "CI95_low": l_, "CI95_high": u_, "t": tt.statistic, "df": df_, "p": tt.pvalue})
se = pd.DataFrame(se_rows); se["p_Bonferroni"] = np.minimum(1, se.p * 3); RESULTS["twoway"]["simple_effects"] = se.to_dict("records")
s_ = se.copy()
for col in ["High_minus_Low", "CI95_low", "CI95_high", "t", "df"]: s_[col] = s_[col].round(3)
for col in ["p", "p_Bonferroni"]: s_[col] = s_[col].map(lambda p: "<0.001" if p < 0.001 else f"{p:.4f}")
display(Markdown("**Table 12. Simple effects: High-Mg minus Low-Mg flavanoids within each cultivar.**")); display(s_)

cell_names = [f"{c[-1]}|{m.split()[0]}" for c in CULT for m in MG]      # e.g. 1|Low
tk6 = tukey_table(cell_groups, cell_names); RESULTS["twoway"]["tukey_cells"] = tk6.to_dict("records")
t6 = tk6.copy()
for col in ["diff", "ci_low", "ci_high"]: t6[col] = t6[col].round(3)
t6["p_adj"] = t6["p_adj"].map(lambda p: "<0.001" if p < 0.001 else f"{p:.4f}")
display(Markdown("**Table 13. Tukey HSD on the 6 cells (labels = cultivar number | magnesium level; difference = first minus second).**")); display(t6)
n_sig = int(tk6.significant.sum())
within_c = [r.comparison for r in tk6.itertuples() if r.significant and r.comparison.split(" - ")[0][0] == r.comparison.split(" - ")[1][0]]
display(Markdown(f"**Tukey HSD:** {n_sig} of 15 cell pairs differ significantly; among the 3 pairs that differ *only* in magnesium level (same cultivar), "
                 f"{len(within_c)} are significant ({', '.join(within_c) if within_c else 'none'})."))

fig, ax = plt.subplots(figsize=(8.5, 6.2)); ypos = np.arange(len(tk6))[::-1]
colr = ["#c0392b" if s else "#555555" for s in tk6.significant]
for y_, (d_, l_, u_, c_) in zip(ypos, zip(tk6["diff"], tk6.ci_low, tk6.ci_high, colr)): ax.errorbar(d_, y_, xerr=[[d_ - l_], [u_ - d_]], fmt="o", color=c_, capsize=3)
ax.axvline(0, color="grey", ls="--"); ax.set_yticks(ypos); ax.set_yticklabels(tk6["comparison"], fontsize=8)
ax.set_xlabel("difference in mean flavanoids (simultaneous 95% Tukey CI; red = significant)"); ax.set_title("Figure 8. Tukey HSD across the six cultivar x magnesium cells")
fig.tight_layout(); fig.savefig(FIG_DIR / "fig8_tukey_twoway_cells.png", dpi=150, bbox_inches="tight")
plt.show()
''')
