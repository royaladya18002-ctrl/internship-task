"""Output contract: structural and logical guarantees every pipeline result must satisfy."""
import math

TOP_KEYS = ["meta", "exclusions", "primary", "robustness", "diagnostics", "decision"]
PRIMARY_KEYS = ["estimand", "beta", "se", "t", "df", "p", "ci_low", "ci_high", "hedges_g", "g_ci_low", "g_ci_high"]
EXCL_KEYS = ["n_input", "missing_required", "duplicate_rows", "implausible_values", "n_analyzed"]
ROB_IDS = ["R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"]
ROB_KEYS = ["label", "estimand", "status", "estimate", "ci_low", "ci_high", "p", "n"]
DIAG_KEYS = ["shapiro_residual_p", "breusch_pagan_p", "max_vif", "n_influential_cooks", "cooks_threshold", "max_leverage"]
DEC_KEYS = ["alpha", "primary_significant", "verdict", "robustness_same_direction", "n_robustness_checks_ok"]


def _fin(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def validate_output(r: dict) -> list:
    """Return a list of contract violations (empty list == contract satisfied)."""
    v = []
    for k in TOP_KEYS:
        if k not in r:
            v.append(f"missing top-level key: {k}")
    if v:
        return v
    for name, keys in (("primary", PRIMARY_KEYS), ("exclusions", EXCL_KEYS),
                       ("diagnostics", DIAG_KEYS), ("decision", DEC_KEYS)):
        for k in keys:
            if k not in r[name]:
                v.append(f"missing {name}.{k}")
    if v:
        return v

    p = r["primary"]
    for k in ["beta", "se", "t", "p", "ci_low", "ci_high", "hedges_g", "g_ci_low", "g_ci_high"]:
        if not _fin(p[k]):
            v.append(f"primary.{k} not finite")
    if not v:
        if not (0.0 <= p["p"] <= 1.0):
            v.append("primary.p outside [0,1]")
        if not (p["ci_low"] <= p["beta"] <= p["ci_high"]):
            v.append("primary CI does not bracket the estimate")
        if p["se"] <= 0:
            v.append("primary.se must be > 0")
        if not (p["g_ci_low"] <= p["hedges_g"] <= p["g_ci_high"]):
            v.append("Hedges g CI does not bracket the estimate")

    e = r["exclusions"]
    if e["n_input"] - e["missing_required"] - e["duplicate_rows"] - e["implausible_values"] != e["n_analyzed"]:
        v.append("exclusion counts do not reconcile to n_analyzed")
    m = r["meta"]
    if m["n_low"] + m["n_high"] + m["n_mid_not_in_primary"] != e["n_analyzed"]:
        v.append("group sizes do not reconcile to n_analyzed")
    if r["primary"].get("df") is not None and r["primary"]["df"] != m["n_low"] + m["n_high"] - 5:
        v.append("primary df != n_primary - 5 parameters")

    for rid in ROB_IDS:
        if rid not in r["robustness"]:
            v.append(f"missing robustness {rid}")
            continue
        x = r["robustness"][rid]
        for k in ROB_KEYS:
            if k not in x:
                v.append(f"{rid} missing {k}")
        if x.get("status") == "ok":
            if not _fin(x["estimate"]):
                v.append(f"{rid} estimate not finite")
            ci_ok = _fin(x["ci_low"]) and _fin(x["ci_high"])
            ci_none = x["ci_low"] is None and x["ci_high"] is None
            p_ok = _fin(x["p"]) and 0.0 <= x["p"] <= 1.0
            if not (ci_ok or ci_none):
                v.append(f"{rid} CI must be both finite or both null")
            if not (ci_ok or p_ok):
                v.append(f"{rid} needs a CI or a p-value")
            if ci_ok and not (x["ci_low"] <= x["ci_high"]):
                v.append(f"{rid} ci_low > ci_high")
            if x["p"] is not None and not p_ok:
                v.append(f"{rid} p outside [0,1]")
        elif x.get("status") != "skipped_small_n":
            v.append(f"{rid} has unknown status {x.get('status')}")

    d = r["diagnostics"]
    for k in ["breusch_pagan_p", "max_vif", "max_leverage"]:
        if not _fin(d[k]):
            v.append(f"diagnostics.{k} not finite")
    if r["decision"]["alpha"] <= 0 or r["decision"]["alpha"] >= 1:
        v.append("decision.alpha outside (0,1)")
    return v
