"""Data loading. Raw units are used (scaled=False) so that BMI, age and blood pressure are interpretable."""
import pandas as pd


def load_raw() -> pd.DataFrame:
    from sklearn.datasets import load_diabetes

    bunch = load_diabetes(as_frame=True, scaled=False)
    return bunch.frame.copy()
