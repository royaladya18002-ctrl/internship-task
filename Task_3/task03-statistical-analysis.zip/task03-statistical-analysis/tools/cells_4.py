CELLS_4 = []
M = lambda s: CELLS_4.append(("markdown", s))
C = lambda s: CELLS_4.append(("code", s))

M(r'''
## 8. Summary of all hypothesis tests (computed from the results above)
''')

C(r'''
rows = []
for v, r in RESULTS["two_sample"].items():
    for t in r["table"]:
        rows.append({"Section": "5", "Test": f"{t['Test']} ({v}, C1 vs C2)", "H0": "identical distributions" if "Mann" in t["Test"] else "equal means",
                     "Statistic": t["Statistic"], "p": t["p"], "Reject at 0.05": t["p"] < ALPHA})
o = RESULTS["oneway"]
rows += [{"Section": "6", "Test": f"One-way ANOVA F({o['dfb']}, {o['dfw']}) proline ~ cultivar", "H0": "3 equal means", "Statistic": o["F"], "p": o["p"], "Reject at 0.05": o["p"] < ALPHA},
         {"Section": "6", "Test": "Welch ANOVA (proline)", "H0": "3 equal means", "Statistic": o["welch_F"], "p": o["welch_p"], "Reject at 0.05": o["welch_p"] < ALPHA},
         {"Section": "6", "Test": "Kruskal-Wallis (proline)", "H0": "identical distributions", "Statistic": o["kruskal_H"], "p": o["kruskal_p"], "Reject at 0.05": o["kruskal_p"] < ALPHA}]
for r_ in RESULTS["twoway"]["type3"][:3]:
    rows.append({"Section": "7", "Test": f"Two-way ANOVA (Type III): {r_['Source']} (flavanoids)", "H0": "no effect", "Statistic": r_["F"], "p": r_["p"], "Reject at 0.05": r_["p"] < ALPHA})
summ = pd.DataFrame(rows); summ_out = summ.copy()
summ_out["Statistic"] = summ_out["Statistic"].round(3); summ_out["p"] = summ_out["p"].map(lambda p: "<0.001" if p < 0.001 else f"{p:.4f}")
display(Markdown("**Table 14. All omnibus and two-sample tests at alpha = 0.05.**")); display(summ_out)
summ.to_csv(RES_DIR / "all_tests_summary.csv", index=False)

def _clean(o):
    if isinstance(o, dict): return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [_clean(v) for v in o]
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, (np.floating, float)): return None if (isinstance(o, float) and math.isnan(o)) else float(o)
    if isinstance(o, (np.bool_,)): return bool(o)
    return o
(RES_DIR / "results.json").write_text(json.dumps(_clean(RESULTS), indent=1))
print("Saved results/all_tests_summary.csv and results/results.json;", len(summ), "tests;", int(summ["Reject at 0.05"].sum()), "rejected at alpha = 0.05")
''')

M(r'''
## 9. Findings
''')

C(r'''
two = RESULTS["two_sample"]; ow_ = RESULTS["oneway"]; tw = RESULTS["twoway"]
t3i = {r["Source"]: r for r in tw["type3"]}; rk3 = {r["Source"]: r for r in tw["rank_type3"]}
tkp = {r["comparison"]: r for r in ow_["tukey"]}; se_ = {r["cultivar"]: r for r in tw["simple_effects"]}
A, B_ = two["alcohol"], two["proline"]; SI = "cultivar x mg_level"
def verdict(p): return "significant" if p < ALPHA else "not significant"
def ci(r, i, f): return "[" + format(r["table"][i]["CI95_low"], f) + ", " + format(r["table"][i]["CI95_high"], f) + "]"
rej_samples = [r["variable"].replace("_", " ") + " / " + r["cultivar"][-1] for r in RESULTS["normality"] if not (r["SW_normal"] and r["KS_normal"])]
sig_simple = [c for c, r in se_.items() if r["p_Bonferroni"] < ALPHA]
sig_txt = ", ".join("Cultivar " + c[-1] for c in sig_simple) if sig_simple else "no cultivar"
within_pairs_sig = [r["comparison"] for r in tw["tukey_cells"] if r["significant"] and r["comparison"].split(" - ")[0][0] == r["comparison"].split(" - ")[1][0]]
methods_agree = (t3i[SI]["p"] < ALPHA) == (rk3[SI]["p"] < ALPHA)
simple_txt = "; ".join("Cultivar " + c[-1] + ": " + format(r["High_minus_Low"], "+.2f") + " (95% CI " + format(r["CI95_low"], ".2f") + " to " + format(r["CI95_high"], ".2f") + ", Bonferroni " + fmt_p(r["p_Bonferroni"]) + ")" for c, r in se_.items())
tk12, tk13, tk23 = tkp["Cultivar 1 - Cultivar 2"], tkp["Cultivar 1 - Cultivar 3"], tkp["Cultivar 2 - Cultivar 3"]
n_sw = sum(not r["SW_normal"] for r in RESULTS["normality"]); n_ks = sum(not r["KS_normal"] for r in RESULTS["normality"])
agree2 = all((r["table"][1]["p"] < ALPHA) == (r["table"][2]["p"] < ALPHA) for r in two.values())
bonf2 = all(min(r["table"][i]["p_Bonferroni"] for i in (1, 2)) < ALPHA for r in two.values())
n_tk_sig = sum(r["significant"] for r in tw["tukey_cells"])

text = f"""
### 9.1 Normality
* Shapiro-Wilk rejected normality in **{n_sw} of 12** samples and the Lilliefors-corrected Kolmogorov-Smirnov test in **{n_ks} of 12**. Samples where at least one test rejects (variable / cultivar number): {', '.join(rej_samples)}. Because some samples are non-normal, rank-based and robust checks accompany every parametric test (Figures 2 and 3).

### 9.2 Two-sample comparisons (Cultivar 1 vs Cultivar 2)
* **Alcohol:** mean {A['means'][0]:.2f} vs {A['means'][1]:.2f}; Welch t-test {verdict(A['table'][1]['p'])} ({fmt_p(A['table'][1]['p'])}), mean difference {A['table'][1]['Estimate']:.2f} with 95% CI {ci(A, 1, '.2f')}; Mann-Whitney U {verdict(A['table'][2]['p'])} ({fmt_p(A['table'][2]['p'])}). Hedges' g = {A['hedges_g'][0]:.2f} (a very large effect). Primary test by the pre-set rule: **{A['primary']}**.
* **Proline:** median {B_['medians'][0]:.0f} vs {B_['medians'][1]:.0f}; Welch t-test {verdict(B_['table'][1]['p'])} ({fmt_p(B_['table'][1]['p'])}), difference {B_['table'][1]['Estimate']:.0f} with 95% CI {ci(B_, 1, '.0f')}; Mann-Whitney U {verdict(B_['table'][2]['p'])} ({fmt_p(B_['table'][2]['p'])}), Hodges-Lehmann shift {B_['table'][2]['Estimate']:.0f} (95% CI {ci(B_, 2, '.0f')}). Hedges' g = {B_['hedges_g'][0]:.2f}. Primary test: **{B_['primary']}**.
* Parametric and non-parametric tests {'agree' if agree2 else 'disagree'} on significance for both comparisons, and both survive the Bonferroni correction for the two planned comparisons: **{bonf2}**.

### 9.3 One-way ANOVA and Tukey HSD (proline across cultivars)
* F({ow_['dfb']}, {ow_['dfw']}) = {ow_['F']:.1f}, {fmt_p(ow_['p'])}, eta-squared = {ow_['eta2']:.2f}: proline differs by cultivar. Residual normality (Shapiro-Wilk {fmt_p(ow_['shapiro_resid_p'])}) and equal variances (Levene {fmt_p(ow_['levene_p'])}) are both rejected, but Welch ANOVA ({fmt_p(ow_['welch_p'])}) and Kruskal-Wallis ({fmt_p(ow_['kruskal_p'])}) reach the same conclusion, so the result does not rest on those assumptions.
* Tukey HSD: Cultivar 1 vs 2 {verdict(tk12['p_adj'])} (diff {tk12['diff']:.0f}, 95% CI [{tk12['ci_low']:.0f}, {tk12['ci_high']:.0f}]); Cultivar 1 vs 3 {verdict(tk13['p_adj'])} (diff {tk13['diff']:.0f}, 95% CI [{tk13['ci_low']:.0f}, {tk13['ci_high']:.0f}]); Cultivar 2 vs 3 {verdict(tk23['p_adj'])} (diff {tk23['diff']:.0f}, 95% CI [{tk23['ci_low']:.0f}, {tk23['ci_high']:.0f}], {fmt_p(tk23['p_adj'])}). Games-Howell and Holm-adjusted Mann-Whitney give the same three decisions (Table 6), so the pairwise conclusions are also robust to unequal variances.

### 9.4 Two-way ANOVA (flavanoids ~ cultivar x magnesium level)
* **Cultivar main effect:** {verdict(t3i['cultivar']['p'])} (F = {t3i['cultivar']['F']:.1f}, {fmt_p(t3i['cultivar']['p'])}, partial eta-squared = {t3i['cultivar']['partial_eta2']:.2f}); the rank-based ANOVA agrees ({fmt_p(rk3['cultivar']['p'])}).
* **Magnesium main effect:** classical {verdict(t3i['mg_level']['p'])} (F = {t3i['mg_level']['F']:.2f}, {fmt_p(t3i['mg_level']['p'])}, partial eta-squared = {t3i['mg_level']['partial_eta2']:.3f}); rank-based {verdict(rk3['mg_level']['p'])} ({fmt_p(rk3['mg_level']['p'])}).
* **Interaction:** classical {verdict(t3i[SI]['p'])} (F = {t3i[SI]['F']:.2f}, {fmt_p(t3i[SI]['p'])}, partial eta-squared = {t3i[SI]['partial_eta2']:.3f}); rank-based {verdict(rk3[SI]['p'])} (F = {rk3[SI]['F']:.2f}, {fmt_p(rk3[SI]['p'])}). The two methods {'agree' if methods_agree else '**disagree**'}.
* **Assumptions:** the two-way residuals are not normal (Shapiro-Wilk {fmt_p(tw['shapiro_resid_p'])}) and cell variances are unequal (Levene {fmt_p(tw['levene_p'])}), so the classical interaction test, which sits right at the 0.05 boundary, should be read with caution. The evidence on the magnesium x cultivar interaction is therefore **borderline and method-dependent**, not settled.
* **Simple effects (High-Mg minus Low-Mg flavanoids):** {simple_txt}. After Bonferroni correction the magnesium difference is significant in: {sig_txt}.
* **Tukey HSD on the six cells:** {n_tk_sig} of 15 pairs differ significantly. **{len(within_pairs_sig)} of the 3** same-cultivar magnesium contrasts reach significance once the family-wise error over all 15 comparisons is controlled (Tukey is conservative and assumes equal variances, which is why it is less sensitive than the simple-effects tests above).

### 9.5 Overall interpretation and limits
* Cultivar is by far the dominant source of variation: proline and flavanoids differ enormously between cultivars (Hedges' g about 3 for the Cultivar 1 vs 2 contrasts; eta-squared about 0.70 for proline, partial eta-squared about 0.70 for flavanoids).
* Magnesium level has a much smaller association with flavanoids. It is {'significant' if t3i['mg_level']['p'] < ALPHA else 'not significant'} as a classical main effect, but the simple-effects analysis suggests a modest positive difference in {sig_txt}; this is reported as an exploratory pattern, not a firm conclusion.
* **Statistical vs practical significance:** the cultivar p-values are tiny because the effects are huge; effect sizes and CIs, not p-values alone, convey the size of the differences.
* **Limits:** the data are observational and come from one region and one era, so conclusions concern these wines, not wines in general. Magnesium was dichotomised at the median for the two-way design, which discards information and makes the design unbalanced (Type III results depend on effect coding). Each test was run at alpha = 0.05 with no overall correction across sections, except where a correction is stated (Tukey, Holm, Bonferroni). Wines are assumed to be independent observations.
"""
display(Markdown(text))
''')

C(r'''
# Consistency guard: the written findings above are generated from the results; these assertions fail loudly
# if a re-run on different data would make the narrative claims untrue.
assert all(r["primary_p"] < ALPHA for r in RESULTS["two_sample"].values()), "two-sample claim"
assert RESULTS["oneway"]["p"] < ALPHA and RESULTS["oneway"]["welch_p"] < ALPHA and RESULTS["oneway"]["kruskal_p"] < ALPHA, "one-way claim"
assert t3i["cultivar"]["p"] < ALPHA and rk3["cultivar"]["p"] < ALPHA, "two-way cultivar claim"
print("Consistency guard passed.")
''')
