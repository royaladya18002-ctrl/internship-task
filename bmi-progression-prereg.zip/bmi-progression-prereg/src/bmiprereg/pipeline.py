"""End-to-end pre-registered pipeline. One public entry point: run_pipeline(df, cfg)."""
import platform
import numpy as np
import pandas as pd
import scipy
import sklearn
from scipy import stats

from . import __version__
from .models import (ols_hc3, hedges_g, breusch_pagan_p, max_vif, bootstrap_coef, permutation_p)
from .prepare import apply_exclusions, assign_exposure, covariate_matrix

ROBUSTNESS_IDS = ["R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"]


def _entry(label, estimand, est, lo, hi, p, n, status="ok"):
    f = lambda v: None if v is None else float(v)
    return {"label": label, "estimand": estimand, "status": status, "estimate": f(est),
            "ci_low": f(lo), "ci_high": f(hi), "p": f(p), "n": int(n)}


def _skipped(label, estimand, n):
    return _entry(label, estimand, None, None, None, None, n, status="skipped_small_n")


def _design(d, group_mask, cov, extra=None):
    """Intercept, exposure indicator (first slope), then covariates."""
    X = pd.DataFrame({"const": 1.0, "exposure_high": group_mask.astype(float)}, index=d.index)
    X = pd.concat([X, cov], axis=1)
    if extra is not None:
        X = pd.concat([X, extra], axis=1)
    return X


def run_pipeline(df: pd.DataFrame, cfg: dict, n_boot=None, n_perm=None) -> dict:
    c = cfg["columns"]
    alpha = cfg["alpha"]
    y_col = c["outcome"]
    n_boot = cfg["resampling"]["bootstrap_B"] if n_boot is None else n_boot
    n_perm = cfg["resampling"]["permutation_B"] if n_perm is None else n_perm
    min_n = cfg["exposure"]["min_group_size"]

    d, excl = apply_exclusions(df, cfg)
    grp = assign_exposure(d[c["exposure"]], cfg)
    q_lo, q_hi = grp.attrs["cutpoints"]
    cov = covariate_matrix(d, cfg)
    y_all = d[y_col].to_numpy(float)

    # ---------------- PRIMARY (confirmatory) ----------------
    sub = grp.isin(["low", "high"]).to_numpy()
    d1, cov1 = d.loc[sub], cov.loc[sub]
    high1 = (grp.loc[sub] == "high")
    X1 = _design(d1, high1, cov1)
    y1 = d1[y_col].to_numpy(float)
    fit = ols_hc3(X1.to_numpy(), y1, alpha)
    j = 1
    g, g_lo, g_hi = hedges_g(y1[high1.to_numpy()], y1[~high1.to_numpy()], alpha)
    n_low, n_high = int((~high1).sum()), int(high1.sum())
    primary = {
        "estimand": "adjusted mean difference in 1-year progression, high vs low BMI tertile",
        "beta": float(fit["beta"][j]), "se": float(fit["se"][j]), "t": float(fit["t"][j]),
        "df": int(fit["df"]), "p": float(fit["p"][j]),
        "ci_low": float(fit["ci_low"][j]), "ci_high": float(fit["ci_high"][j]),
        "hedges_g": g, "g_ci_low": g_lo, "g_ci_high": g_hi,
    }

    # ---------------- DIAGNOSTICS (reported, never used to alter the primary model) ----------------
    thr = 4.0 / fit["n"]
    shapiro_p = float(stats.shapiro(fit["resid"]).pvalue) if fit["n"] >= 3 else None
    diagnostics = {
        "shapiro_residual_p": shapiro_p,
        "breusch_pagan_p": breusch_pagan_p(X1.to_numpy(), fit["resid"]),
        "max_vif": max_vif(X1.drop(columns="const").to_numpy()),
        "n_influential_cooks": int((fit["cooks"] > thr).sum()),
        "cooks_threshold": float(thr),
        "max_leverage": float(fit["leverage"].max()),
    }

    rob = {}
    rng = np.random.default_rng(cfg["seed"])

    # R1 continuous BMI, per 1 SD, full analytic sample
    bmi = d[c["exposure"]].to_numpy(float)
    sd = bmi.std(ddof=1)
    X = pd.concat([pd.DataFrame({"const": 1.0, "bmi_z": (bmi - bmi.mean()) / sd}, index=d.index), cov], axis=1)
    f = ols_hc3(X.to_numpy(), y_all, alpha)
    rob["R1"] = _entry("Continuous BMI, per 1 SD (full sample)", "adjusted slope per SD of BMI",
                       f["beta"][1], f["ci_low"][1], f["ci_high"][1], f["p"][1], f["n"])

    # R2 Welch t-test, unadjusted, high vs low
    hi_y, lo_y = y1[high1.to_numpy()], y1[~high1.to_numpy()]
    w = stats.ttest_ind(hi_y, lo_y, equal_var=False)
    ci = w.confidence_interval(1 - alpha)
    rob["R2"] = _entry("Welch t-test, unadjusted", "unadjusted mean difference, high vs low",
                       hi_y.mean() - lo_y.mean(), ci.low, ci.high, w.pvalue, len(y1))

    # R3 bootstrap percentile CI for the primary coefficient
    lo, hi = bootstrap_coef(X1.to_numpy(), y1, j, n_boot, rng, alpha)
    rob["R3"] = _entry("Case-resampling bootstrap CI", "adjusted mean difference (percentile CI)",
                       primary["beta"], lo, hi, None, len(y1))

    # R4 permutation test of exposure label
    pp = permutation_p(X1.to_numpy(), y1, j, n_perm, rng)
    rob["R4"] = _entry("Permutation test of exposure label", "adjusted mean difference (permutation p)",
                       primary["beta"], None, None, pp, len(y1))

    # R5 extended covariate adjustment (serum measures; potential mediators -> sensitivity only)
    ext = [k for k in c["extended_covariates"] if k in d.columns]
    ok_rows = d1[ext].notna().all(axis=1)
    X5 = _design(d1.loc[ok_rows], high1.loc[ok_rows], cov1.loc[ok_rows], d1.loc[ok_rows, ext].astype(float))
    f5 = ols_hc3(X5.to_numpy(), d1.loc[ok_rows, y_col].to_numpy(float), alpha)
    rob["R5"] = _entry("Extended adjustment (+ s1-s6)", "adjusted mean difference, extra serum covariates",
                       f5["beta"][1], f5["ci_low"][1], f5["ci_high"][1], f5["p"][1], f5["n"])

    # R6 log-transformed outcome
    f6 = ols_hc3(X1.to_numpy(), np.log(y1), alpha)
    rob["R6"] = _entry("Log outcome", "adjusted difference in ln(progression)",
                       f6["beta"][1], f6["ci_low"][1], f6["ci_high"][1], f6["p"][1], f6["n"])

    # R7 WHO categories: >=30 vs <25 (full sample)
    e = cfg["exposure"]
    who_hi = bmi >= e["who_high_min_inclusive"]
    who_lo = bmi < e["who_low_max_exclusive"]
    if who_hi.sum() < min_n or who_lo.sum() < min_n:
        rob["R7"] = _skipped("WHO categories (>=30 vs <25)", "adjusted mean difference", int(who_hi.sum() + who_lo.sum()))
    else:
        m = who_hi | who_lo
        dm = d.loc[m]
        X7 = _design(dm, pd.Series(who_hi[m], index=dm.index), cov.loc[m])
        f7 = ols_hc3(X7.to_numpy(), dm[y_col].to_numpy(float), alpha)
        rob["R7"] = _entry("WHO categories (>=30 vs <25)", "adjusted mean difference, obese vs normal/under-weight",
                           f7["beta"][1], f7["ci_low"][1], f7["ci_high"][1], f7["p"][1], f7["n"])

    # R8 drop influential observations (Cook's D > 4/n) and refit primary
    keep = fit["cooks"] <= thr
    f8 = ols_hc3(X1.to_numpy()[keep], y1[keep], alpha)
    rob["R8"] = _entry("Influence-trimmed (Cook's D <= 4/n)", "adjusted mean difference without influential rows",
                       f8["beta"][1], f8["ci_low"][1], f8["ci_high"][1], f8["p"][1], f8["n"])

    # ---------------- DECISION (pre-specified rule) ----------------
    sig = primary["p"] < alpha
    if sig and primary["beta"] > 0:
        verdict = "supported: higher BMI associated with greater progression"
    elif sig and primary["beta"] < 0:
        verdict = "contradicted: association significant but opposite to expected direction"
    else:
        verdict = "not supported: null hypothesis not rejected"
    signs = [np.sign(r["estimate"]) for r in rob.values() if r["status"] == "ok"]
    decision = {
        "alpha": alpha, "primary_significant": bool(sig), "verdict": verdict,
        "robustness_same_direction": bool(all(s == np.sign(primary["beta"]) for s in signs)),
        "n_robustness_checks_ok": len(signs),
    }

    meta = {
        "pipeline_version": __version__, "seed": int(cfg["seed"]),
        "bmi_cutpoints": {"low_max": q_lo, "high_min": q_hi},
        "n_low": n_low, "n_high": n_high, "n_mid_not_in_primary": int((grp == "mid").sum()),
        "bootstrap_B": int(n_boot), "permutation_B": int(n_perm),
        "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
        "pandas": pd.__version__, "sklearn": sklearn.__version__,
    }
    return {"meta": meta, "exclusions": excl, "primary": primary, "robustness": rob,
            "diagnostics": diagnostics, "decision": decision}
