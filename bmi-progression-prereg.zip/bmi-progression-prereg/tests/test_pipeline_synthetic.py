"""Data-blind pipeline check on synthetic fixtures: correctness, determinism, contracts and guards."""
import copy
import inspect
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.linear_model import LinearRegression

from bmiprereg import lock as lockmod
from bmiprereg.config import load_config, ROOT
from bmiprereg.contracts import validate_output, ROB_IDS
from bmiprereg.data import load_raw
from bmiprereg.models import ols_hc3
from bmiprereg.pipeline import run_pipeline
from bmiprereg.prepare import apply_exclusions, assign_exposure
from synthetic import make_synthetic

CFG = load_config()
FAST = dict(n_boot=200, n_perm=200)
GOLDEN = Path(__file__).parent / "expected" / "synthetic_golden.json"


def test_exclusion_counts_exact():
    d, c = apply_exclusions(make_synthetic(messy=True), CFG)
    assert c["n_input"] == 604
    assert c["missing_required"] == 8
    assert c["duplicate_rows"] == 4
    assert c["implausible_values"] == 5
    assert c["n_analyzed"] == 587 and len(d) == 587


def test_primary_ci_coverage_of_planted_effect():
    cover = 0
    reps = 300
    for s in range(reps):
        r = run_pipeline_primary_only(make_synthetic(n=300, delta=15, seed=1000 + s))
        cover += r["ci_low"] <= 15 <= r["ci_high"]
    assert 0.90 <= cover / reps <= 0.99


def run_pipeline_primary_only(df):
    d, _ = apply_exclusions(df, CFG)
    g = assign_exposure(d["bmi"], CFG)
    m = g.isin(["low", "high"]).to_numpy()
    s = d.loc[m]
    X = np.column_stack([np.ones(len(s)), (g[m] == "high").astype(float), s["age"], (s["sex"] == 2).astype(float), s["bp"]])
    f = ols_hc3(X, s["target"].to_numpy())
    return {"beta": f["beta"][1], "p": f["p"][1], "ci_low": f["ci_low"][1], "ci_high": f["ci_high"][1]}


def test_null_false_positive_rate_near_alpha():
    reps = 300
    fp = sum(run_pipeline_primary_only(make_synthetic(n=300, delta=0, seed=5000 + s))["p"] < 0.05 for s in range(reps))
    assert 0.02 <= fp / reps <= 0.09


def test_ols_matches_independent_reference():
    d = make_synthetic(n=120, delta=10, seed=3)
    X = np.column_stack([np.ones(120), d["bmi"] > 26, d["age"], d["bp"]]).astype(float)
    y = d["target"].to_numpy()
    f = ols_hc3(X, y)
    sk = LinearRegression(fit_intercept=False).fit(X, y)
    assert np.allclose(f["beta"], sk.coef_, atol=1e-8)
    # brute-force HC3 sandwich with explicit loops
    xtx_inv = np.linalg.pinv(X.T @ X)
    e = y - X @ sk.coef_
    meat = np.zeros((4, 4))
    for i in range(120):
        h = X[i] @ xtx_inv @ X[i]
        meat += (e[i] / (1 - h)) ** 2 * np.outer(X[i], X[i])
    assert np.allclose(f["se"], np.sqrt(np.diag(xtx_inv @ meat @ xtx_inv)), rtol=1e-8)


def test_exposure_assignment_is_blind_to_outcome():
    params = list(inspect.signature(assign_exposure).parameters)
    assert params == ["bmi", "cfg"]
    d = make_synthetic(seed=9)
    a = assign_exposure(d["bmi"], CFG)
    d2 = d.assign(target=np.random.default_rng(0).permutation(d["target"].to_numpy()))
    b = assign_exposure(d2["bmi"], CFG)
    assert (a == b).all()


def test_deterministic_and_seed_sensitive():
    d = make_synthetic(seed=2, delta=12)
    r1, r2 = run_pipeline(d, CFG, **FAST), run_pipeline(d, CFG, **FAST)
    assert json.dumps(r1, sort_keys=True) == json.dumps(r2, sort_keys=True)
    cfg2 = copy.deepcopy(CFG)
    cfg2["seed"] = 1
    r3 = run_pipeline(d, cfg2, **FAST)
    assert r3["primary"] == r1["primary"]
    assert r3["robustness"]["R3"]["ci_low"] != r1["robustness"]["R3"]["ci_low"]


def test_output_contract_satisfied_and_all_checks_present():
    r = run_pipeline(make_synthetic(seed=4, delta=12), CFG, **FAST)
    assert validate_output(r) == []
    assert set(r["robustness"]) == set(ROB_IDS)


def test_contract_detects_violations():
    r = run_pipeline(make_synthetic(seed=4, delta=12), CFG, **FAST)
    bad = copy.deepcopy(r); bad["primary"]["beta"] = float("nan")
    assert validate_output(bad)
    bad = copy.deepcopy(r); bad["primary"]["ci_low"] = bad["primary"]["beta"] + 1
    assert validate_output(bad)
    bad = copy.deepcopy(r); bad["exclusions"]["n_analyzed"] += 1
    assert validate_output(bad)
    bad = copy.deepcopy(r); del bad["robustness"]["R5"]
    assert validate_output(bad)
    bad = copy.deepcopy(r); bad["robustness"]["R4"]["p"] = 1.5
    assert validate_output(bad)


def test_messy_fixture_passes_through_pipeline_and_contract():
    r = run_pipeline(make_synthetic(seed=6, delta=8, messy=True), CFG, **FAST)
    assert validate_output(r) == []
    assert r["exclusions"]["n_analyzed"] == 587


def test_who_check_skips_when_group_too_small():
    d = make_synthetic(seed=7, delta=5)
    d["bmi"] = d["bmi"].clip(upper=28.0)       # nobody >= 30
    r = run_pipeline(d, CFG, **FAST)
    assert r["robustness"]["R7"]["status"] == "skipped_small_n"
    assert validate_output(r) == []


def test_planted_effect_recovered_in_full_pipeline():
    r = run_pipeline(make_synthetic(n=1500, seed=8, delta=20, noise_sd=30), CFG, **FAST)
    assert abs(r["primary"]["beta"] - 20) < 3 * r["primary"]["se"]
    assert r["decision"]["verdict"].startswith("supported")
    r0 = run_pipeline(make_synthetic(n=1500, seed=8, delta=0, noise_sd=30), CFG, **FAST)
    assert r0["primary"]["ci_low"] < 0 < r0["primary"]["ci_high"]


def test_golden_output_regression():
    r = run_pipeline(make_synthetic(seed=11, delta=10), CFG, **FAST)
    golden = json.loads(GOLDEN.read_text())
    for k in ["beta", "se", "p", "ci_low", "ci_high", "hedges_g"]:
        assert r["primary"][k] == pytest.approx(golden["primary"][k], rel=1e-8, abs=1e-10)
    assert r["exclusions"] == golden["exclusions"]


def test_real_data_structure_audit_is_outcome_blind():
    """Structure only: row count, predictor columns, predictor missingness. No outcome relationships examined."""
    df = load_raw()
    assert df.shape == (CFG["dataset"]["expected_rows"], 11)
    assert df.drop(columns="target").isna().sum().sum() == 0


def test_lock_detects_tampering(tmp_path):
    for f in lockmod.LOCKED_FILES:
        dst = tmp_path / f
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(ROOT / f, dst)
    ok, _ = lockmod.verify_lock(tmp_path)
    assert not ok                                   # not locked yet
    lockmod.create_lock(tmp_path)
    assert lockmod.verify_lock(tmp_path) == (True, [])
    (tmp_path / "config/analysis_config.json").write_text('{"alpha": 0.2}')
    ok, problems = lockmod.verify_lock(tmp_path)
    assert not ok and "config/analysis_config.json" in problems[0]
