# Task 03: Advanced Statistical Analysis & Hypothesis Testing

Deliverable: `notebooks/Task03_Statistical_Analysis.ipynb` (all outputs and figures embedded).

* Dataset: UCI Wine (178 wines, 3 cultivars; bundled with scikit-learn, works offline).
* Contents: Shapiro-Wilk and Kolmogorov-Smirnov (plain and Lilliefors) normality tests; Student/Welch t-tests and Mann-Whitney U; one-way ANOVA with Tukey HSD (plus Welch ANOVA, Kruskal-Wallis, Games-Howell); two-way ANOVA with interaction (Type II/III) and Tukey HSD; hypotheses and 95% CIs in markdown; distribution plots; findings.
* `figures/` PNGs of every figure, `results/` machine-readable results, `reports/` the written report.
* Re-run: `pip install -r requirements.lock jupyterlab`, open the notebook, Run All (or `python tools/build.py`, which re-executes it without Jupyter).
