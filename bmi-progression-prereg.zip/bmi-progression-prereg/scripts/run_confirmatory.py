"""Confirmatory run on the real data. Refuses to run unless (1) the plan lock verifies and
(2) the data-blind synthetic check last passed. Writes interim/processed data and results JSON."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from bmiprereg.config import load_config  # noqa: E402
from bmiprereg.contracts import validate_output  # noqa: E402
from bmiprereg.data import load_raw  # noqa: E402
from bmiprereg.lock import verify_lock  # noqa: E402
from bmiprereg.pipeline import run_pipeline  # noqa: E402
from bmiprereg.prepare import apply_exclusions  # noqa: E402

ok, problems = verify_lock(ROOT)
if not ok:
    sys.exit("REFUSING TO RUN - plan lock failed:\n  " + "\n  ".join(problems))
rep = ROOT / "reports" / "synthetic_check_report.json"
if not rep.exists() or not json.loads(rep.read_text())["passed"]:
    sys.exit("REFUSING TO RUN - data-blind synthetic check missing or failed (run scripts/run_data_blind_check.py)")

cfg = load_config()
raw = load_raw()
raw.to_csv(ROOT / "data/raw/diabetes_raw.csv", index=False)
clean, _ = apply_exclusions(raw, cfg)
clean.to_csv(ROOT / "data/interim/diabetes_clean.csv", index=False)
res = run_pipeline(raw, cfg)
violations = validate_output(res)
if violations:
    sys.exit("Output contract violated:\n  " + "\n  ".join(violations))
(ROOT / "data/processed/results.json").write_text(json.dumps(res, indent=2) + "\n")
print(json.dumps({"primary": res["primary"], "decision": res["decision"]}, indent=2))
