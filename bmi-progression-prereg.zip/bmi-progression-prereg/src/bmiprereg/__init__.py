"""Pre-registered analysis pipeline: baseline BMI and 1-year diabetes progression."""
__version__ = "1.0.0"
