# Analysis Preregistration

**Title:** Baseline body-mass index and one-year disease progression in patients with diabetes
**Plan version:** 1.0.0 (locked before any outcome relationship was examined; see `PREREG_LOCK.json`)
**Dataset:** Diabetes dataset of Efron, Hastie, Johnstone & Tibshirani (2004), loaded with `sklearn.datasets.load_diabetes(scaled=False)` (raw measurement units).

**Outcome-blind status declaration.** Before this plan was locked, the only things inspected in the real data were: number of rows and columns, the names and units of predictor columns, missing/duplicate counts, and the marginal range of predictor columns (age, sex code, BMI, blood pressure, serum measures). No relationship between any predictor and the outcome column `target` was computed, plotted or viewed. The outcome column was inspected only for its count of missing values.

## Research question
Among patients with diabetes, is a higher baseline BMI (top tertile) associated with a greater quantitative disease-progression score one year after baseline than a lower baseline BMI (bottom tertile), after adjusting for age, sex and mean blood pressure?

### PICO / observation window
| Element | Definition |
|---|---|
| **Population** | Adult patients with diabetes represented in the Efron et al. (2004) dataset (n = 442 records, ages 19-79). |
| **Exposure** | Higher baseline BMI: BMI at or above the upper sample tertile (>= 66.67th percentile of the analysed sample). |
| **Comparator** | Lower baseline BMI: BMI at or below the lower sample tertile (<= 33.33th percentile). The middle tertile is excluded from the primary contrast. |
| **Outcome** | `target`: quantitative measure of disease progression one year after baseline (continuous, higher = more progression). |
| **Observation window** | 12 months: exposure and covariates measured at baseline; outcome measured one year after baseline. |

## Hypotheses
* **H0 (null):** After adjustment for age, sex and mean blood pressure, the mean one-year progression score is the same in the high-BMI and low-BMI tertiles (beta_exposure = 0).
* **H1 (alternative):** The adjusted mean progression scores differ (beta_exposure != 0). The test is **two-sided**.
* **Expected direction (justified):** Positive, i.e. higher BMI -> higher progression, because adiposity worsens insulin resistance and glycaemic control. A result is reported as *supported* only if p < alpha **and** beta > 0; a significant negative beta is reported as *contradicted* (opposite to expectation), not as support.
* **Hypothesis count / multiplicity:** One confirmatory hypothesis, so no multiplicity correction. Robustness checks R1-R8 are sensitivity analyses and are not used for additional significance claims.

## Population, sample, and exclusions
* **Target population:** adults with diabetes comparable to the source cohort.
* **Unit of analysis:** one patient record (one row).
* **Inclusion rules:** every record in the dataset with non-missing BMI, age, sex, mean blood pressure and outcome.
* **Exclusion rules (applied in this order; each row is counted under the first rule it fails):**
  1. Missing value in any of: BMI, outcome, age, sex, blood pressure.
  2. Exact duplicate rows (first occurrence kept).
  3. Implausible values: BMI outside [10, 70]; age outside [18, 100]; outcome <= 0.
  4. Primary contrast only: records in the middle BMI tertile are not part of the primary comparison (they remain in R1).
* **Stopping rule / sample size:** fixed sample. All 442 available records are analysed once. No interim looks, no optional stopping, no additional data collection. No a-priori power calculation is possible because the sample is fixed; the achieved precision (CI width) is reported instead.

## Variables and measures
| Role | Variable | Definition |
|---|---|---|
| Outcome | `target` | Disease-progression score at one year (continuous, untransformed in the primary model). |
| Exposure | `bmi` | Baseline BMI (kg/m^2). Primary coding: indicator for top tertile vs bottom tertile. Cut-points are computed on the analysed sample with `numpy.quantile` (linear interpolation) at 1/3 and 2/3; low = BMI <= lower cut-point, high = BMI >= upper cut-point. |
| Covariate | `age` | Age in years (continuous, linear). |
| Covariate | `sex` | Indicator for the code `2` (the source does not document the coding; no interpretation of the code is assumed). |
| Covariate | `bp` | Average (mean arterial) blood pressure, continuous, linear. |
| Sensitivity only | `s1`-`s6` | Six baseline blood-serum measures; used only in R5 because they may lie on the causal pathway from BMI to progression (potential mediators), so they are not in the primary model. |

* **Transformations:** none in the primary model. Sensitivity R1 standardises BMI (z-score on the analysed sample); R6 takes the natural log of the outcome. Raw measurement units (`scaled=False`) are used so results are interpretable.
* **Missing-data handling:** complete-case analysis. Missing counts are reported under exclusion rule 1. No imputation. (The source file is expected to have none; the rule exists so the pipeline is well defined on any input.)

## Analysis plan
* **Primary model (confirmatory):** ordinary least squares on the low- and high-tertile records: `progression ~ 1 + high_BMI + age + sex_2 + bp`, with HC3 heteroskedasticity-robust standard errors and Student-t inference with n-5 degrees of freedom.
* **Primary estimate:** beta of `high_BMI` = adjusted mean difference in progression score (high minus low), with a 95% CI and a two-sided p-value.
* **Alpha:** 0.05, two-sided; 95% confidence intervals.
* **Effect sizes:** (i) adjusted mean difference in score units; (ii) Hedges' g (small-sample-corrected standardised mean difference, unadjusted pooled SD) with an approximate 95% CI. Interpretation guide: |g| ~0.2 small, ~0.5 medium, ~0.8 large, treated as conventions and not as thresholds.
* **Assumptions and diagnostics (reported, never used to alter the primary model):** residual normality (Shapiro-Wilk), heteroskedasticity (Breusch-Pagan; already handled by HC3), multicollinearity (maximum VIF), influence (Cook's D > 4/n, maximum leverage). Linearity of covariates is assumed and is not tuned after seeing the outcome.
* **Pre-specified robustness / sensitivity checks:**
  * **R1** Continuous BMI (per 1 SD) on the full analysed sample, same covariates.
  * **R2** Welch t-test of the unadjusted high vs low difference.
  * **R3** Case-resampling bootstrap (B = 5000, percentile 95% CI) for the primary coefficient.
  * **R4** Permutation test (B = 10000) of the exposure label in the primary model.
  * **R5** Primary model plus serum covariates s1-s6.
  * **R6** Primary model on ln(outcome).
  * **R7** WHO categories: BMI >= 30 vs BMI < 25 on the full sample (skipped, and said so, if either group has fewer than 10 records).
  * **R8** Primary model after dropping records with Cook's D > 4/n.
* **Decision rule:** Conclusion is determined by the primary test only (see Hypotheses). The result is described as *robust* if all non-skipped checks R1-R8 have the same sign as the primary estimate; disagreement is reported in full, and the primary conclusion is not changed by robustness results.
* **Reproducibility controls:** exact environment lockfile, one master seed (20261109), SHA-256 lock of this document, config, code, lockfile and output contract; automated data-blind pipeline test on synthetic fixtures must pass before the confirmatory script will run.

## Deviations
Record every later deviation from this plan with a timestamp and reason. Format: `YYYY-MM-DDThh:mm:ssZ | section | what changed | reason | effect on conclusions`.

| Timestamp (UTC) | Section | Change | Reason | Effect |
|---|---|---|---|---|
| *(none recorded at lock time)* | | | | |
