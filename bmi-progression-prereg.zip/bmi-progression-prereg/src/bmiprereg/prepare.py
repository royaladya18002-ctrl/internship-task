"""Preparation steps: exclusions, exposure assignment, design matrices.

DATA-BLINDNESS: `assign_exposure` receives ONLY the exposure column. It cannot see the outcome,
so group membership cannot depend on outcome patterns (verified by a unit test).
"""
import numpy as np
import pandas as pd


def apply_exclusions(df: pd.DataFrame, cfg: dict):
    c = cfg["columns"]
    ex = cfg["exclusions"]
    required = [c["exposure"], c["outcome"]] + list(c["covariates"])
    counts = {"n_input": int(len(df))}

    miss = df[required].isna().any(axis=1)
    counts["missing_required"] = int(miss.sum())
    d = df.loc[~miss]

    if ex["drop_exact_duplicates"]:
        dup = d.duplicated(keep="first")
    else:
        dup = pd.Series(False, index=d.index)
    counts["duplicate_rows"] = int(dup.sum())
    d = d.loc[~dup]

    bad = (
        (d[c["exposure"]] < ex["bmi_range"][0]) | (d[c["exposure"]] > ex["bmi_range"][1])
        | (d["age"] < ex["age_range"][0]) | (d["age"] > ex["age_range"][1])
        | (d[c["outcome"]] <= ex["outcome_min_exclusive"])
    )
    counts["implausible_values"] = int(bad.sum())
    d = d.loc[~bad].reset_index(drop=True)
    counts["n_analyzed"] = int(len(d))
    return d, counts


def assign_exposure(bmi: pd.Series, cfg: dict) -> pd.Series:
    """Return 'low' / 'mid' / 'high' by sample tertiles of BMI. Sees ONLY the exposure column."""
    e = cfg["exposure"]
    q_lo = float(np.quantile(bmi, e["low_quantile"]))
    q_hi = float(np.quantile(bmi, e["high_quantile"]))
    if not q_lo < q_hi:
        raise ValueError("Degenerate BMI tertiles: low cut-point >= high cut-point")
    grp = pd.Series("mid", index=bmi.index)
    grp[bmi <= q_lo] = "low"
    grp[bmi >= q_hi] = "high"
    grp.attrs["cutpoints"] = (q_lo, q_hi)
    return grp


def covariate_matrix(d: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    c = cfg["columns"]
    out = pd.DataFrame(
        {
            "age": d["age"].astype(float),
            "sex_" + str(int(c["sex_indicator_value"])): (d["sex"] == c["sex_indicator_value"]).astype(float),
            "bp": d["bp"].astype(float),
        }
    )
    return out
