---
title: "Task 03: Advanced Statistical Analysis & Hypothesis Testing"
subtitle: "Parametric and non-parametric inference, ANOVA and Tukey HSD on the UCI Wine dataset"
date: "9 November 2026"
---

# 1. Requirement checklist

The brief asks for rigorous inferential statistics on a scientific or business dataset, with parametric and non-parametric tests and ANOVA. The expected proof is a Jupyter Notebook containing statistical tests, distribution plots and findings.

| # | Requirement | Where it is met |
|---|---|---|
| 1 | Shapiro-Wilk normality tests on sample distributions | Notebook Section 4.1; 12 samples (4 variables x 3 cultivars), plus residual checks in Sections 6 and 7 |
| 2 | Kolmogorov-Smirnov normality tests | Notebook Section 4.2; plain KS and Lilliefors-corrected KS |
| 3 | Two-sample t-tests, significance at p < 0.05 | Section 5; Student and Welch versions |
| 4 | Mann-Whitney U tests, significance at p < 0.05 | Section 5 |
| 5 | One-Way ANOVA | Section 6 (proline across 3 cultivars) |
| 6 | Two-Way ANOVA | Section 7 (flavanoids by cultivar x magnesium level, with interaction) |
| 7 | Tukey HSD post-hoc analysis across multiple groups | Sections 6.4 (3 groups) and 7.5 (6 cells, 15 pairs) |
| 8 | Null and alternative hypotheses documented in markdown | A hypothesis block before every test family |
| 9 | Confidence intervals documented | 95% CIs for means, mean differences, Hodges-Lehmann shifts, Hedges' g and Tukey differences |
| 10 | Distribution plots | Figures 1 to 8 (notebook and Section 6 of this report) |
| 11 | Findings | Notebook Sections 8 and 9; Section 5 of this report |
| 12 | Expected proof: .ipynb with tests, plots and findings | `Task03_Statistical_Analysis.ipynb`, outputs embedded |

All tests use alpha = 0.05 (two-sided). The brief's "submit one public link" step needs the notebook uploaded somewhere public (see Section 8); that is the one step I cannot do from here.

# 2. Dataset and design

* **Dataset:** UCI Wine (Forina et al., 1991): 178 wines from three cultivars (59, 71 and 48 wines), 13 chemical measurements each, no missing values and no duplicates. It ships with scikit-learn, so the work runs offline.
* **Variables analysed:** alcohol, flavanoids, proline and colour intensity (normality); alcohol and proline (two-sample tests); proline (one-way ANOVA); flavanoids by cultivar x magnesium level (two-way ANOVA; magnesium split at the median of 98 into Low and High).
* **Choices fixed before testing:** the variables, comparisons, alpha and the rule for choosing the primary two-sample test (Welch t if both groups pass Shapiro-Wilk, otherwise Mann-Whitney U). Both test families are always reported.

# 3. Methods, with hypotheses

* **Normality (each of 12 samples).** H0: the sample comes from a normal distribution; H1: it does not. Shapiro-Wilk, plain KS, and Lilliefors-corrected KS (10,000-simulation null, needed because mean and SD are estimated from the data). Decisions use the corrected KS p-value.
* **Two-sample tests (Cultivar 1 vs 2).** t-test H0: equal means, H1: different means (Student and Welch, 95% CI for the difference). Mann-Whitney H0: identical distributions, H1: one is stochastically larger (95% bootstrap CI for the Hodges-Lehmann shift). Effect sizes: Hedges' g and rank-biserial r. Bonferroni adjustment for two planned comparisons.
* **One-way ANOVA.** H0: the three cultivar means are equal; H1: at least one differs. Checks: residual normality, Levene's test, Welch ANOVA and Kruskal-Wallis. Tukey HSD for each pair (H0: mu_i = mu_j), with Games-Howell and Holm-adjusted Mann-Whitney as robustness checks.
* **Two-way ANOVA.** Three hypothesis pairs: no cultivar effect, no magnesium effect, no interaction. Type III sums of squares with effect coding (the design is unbalanced), Type II for comparison, a rank-based ANOVA as the distribution-free check, simple effects, and Tukey HSD over the 6 cells.
* **Validation.** The custom pieces (Lilliefors KS, Welch ANOVA, Games-Howell, Hodges-Lehmann, two-way ANOVA) were checked against scipy and closed-form formulas inside the notebook before use. I also recomputed the headline figures separately: one-way F, Welch t, Mann-Whitney U, Kruskal-Wallis H, Tukey p-values and the two-way residual sum of squares all matched.

# 4. Results

## 4.1 Normality

Shapiro-Wilk rejected normality in 4 of 12 samples and the Lilliefors-corrected KS test in 6 of 12. The plain KS test rejected in none, which is the expected conservatism when parameters are estimated.

| Variable | Cultivar | n | SW W | SW p | KS D | KS p (Lilliefors) | Decision SW / KS |
|---|---|---|---|---|---|---|---|
| alcohol | Cultivar 1 | 59 | 0.981 | 0.479 | 0.069 | 0.674 | normal / normal |
| alcohol | Cultivar 2 | 71 | 0.972 | 0.114 | 0.108 | 0.039 | normal / reject |
| alcohol | Cultivar 3 | 48 | 0.981 | 0.641 | 0.093 | 0.365 | normal / normal |
| flavanoids | Cultivar 1 | 59 | 0.984 | 0.639 | 0.076 | 0.530 | normal / normal |
| flavanoids | Cultivar 2 | 71 | 0.937 | 0.001 | 0.116 | 0.019 | reject / reject |
| flavanoids | Cultivar 3 | 48 | 0.892 | <0.001 | 0.172 | 0.002 | reject / reject |
| proline | Cultivar 1 | 59 | 0.982 | 0.523 | 0.065 | 0.765 | normal / normal |
| proline | Cultivar 2 | 71 | 0.939 | 0.002 | 0.133 | 0.004 | reject / reject |
| proline | Cultivar 3 | 48 | 0.977 | 0.458 | 0.063 | 0.906 | normal / normal |
| color intensity | Cultivar 1 | 59 | 0.968 | 0.125 | 0.073 | 0.589 | normal / normal |
| color intensity | Cultivar 2 | 71 | 0.932 | <0.001 | 0.142 | 0.002 | reject / reject |
| color intensity | Cultivar 3 | 48 | 0.958 | 0.088 | 0.144 | 0.015 | normal / reject |

![Figure 2. Histograms with fitted normal curves](../figures/fig2_histograms_normal_fit.png){width=6in}

## 4.2 Two-sample tests

**Alcohol, Cultivar 1 (mean 13.74) vs Cultivar 2 (mean 12.28).** Both groups pass Shapiro-Wilk, so the Welch t-test is primary. Hedges' g = 2.89 (95% CI 2.39 to 3.38).

| Test | Statistic | p | Estimate | 95% CI |
|---|---|---|---|---|
| Student t (equal var.) | 16.48 | <0.001 | 1.47 (mean difference) | [1.29, 1.64] |
| Welch t (unequal var.) | 16.71 | <0.001 | 1.47 (mean difference) | [1.29, 1.64] |
| Mann-Whitney U | 4079.50 | <0.001 | 1.49 (Hodges-Lehmann shift) | [1.31, 1.68] |

**Proline, Cultivar 1 (mean 1116) vs Cultivar 2 (mean 520).** Cultivar 2 fails Shapiro-Wilk and variances differ (Levene p = 0.011), so Mann-Whitney U is primary. Hedges' g = 3.13; rank-biserial r = 0.97.

| Test | Statistic | p | Estimate | 95% CI |
|---|---|---|---|---|
| Student t (equal var.) | 17.90 | <0.001 | 596.20 (mean difference) | [530.30, 662.11] |
| Welch t (unequal var.) | 17.36 | <0.001 | 596.20 (mean difference) | [528.07, 664.34] |
| Mann-Whitney U | 4133.00 | <0.001 | 601.00 (Hodges-Lehmann shift) | [533.00, 665.00] |

Decision: H0 is rejected for both variables by every test (p < 0.05), and both also survive the Bonferroni correction for two comparisons.

![Figure 4. Two-sample comparisons](../figures/fig4_two_sample_comparisons.png){width=6in}

## 4.3 One-way ANOVA and Tukey HSD (proline)

F(2, 175) = 207.92, p < 0.001, eta-squared = 0.704, omega-squared = 0.699. H0 is rejected. Residual normality (p = 0.021) and equal variances (Levene p < 0.001) are both rejected, but Welch ANOVA (F = 153.8, p < 0.001) and Kruskal-Wallis (H = 119.1, p < 0.001) agree with the classical result.

| Pair | Mean difference | Simultaneous 95% CI | Tukey adjusted p | Significant |
|---|---|---|---|---|
| Cultivar 1 - Cultivar 2 | 596.2 | [524.4, 668.0] | <0.001 | Yes |
| Cultivar 1 - Cultivar 3 | 485.8 | [406.6, 565.0] | <0.001 | Yes |
| Cultivar 2 - Cultivar 3 | -110.4 | [-186.5, -34.3] | 0.0022 | Yes |

All three pairs differ, and Games-Howell and Holm-adjusted Mann-Whitney give identical decisions.

![Figure 6. Tukey HSD pairwise differences](../figures/fig6_tukey_oneway.png){width=5in}

## 4.4 Two-way ANOVA and Tukey HSD (flavanoids)

Cell sizes (unbalanced): Cultivar 1 has 16 Low-Mg and 43 High-Mg wines, Cultivar 2 has 52 and 19, Cultivar 3 has 28 and 20.

| Source (Type III) | SS | df | MS | F | p | Partial eta-squared |
|---|---|---|---|---|---|---|
| cultivar | 104.910 | 2 | 52.455 | 196.40 | <0.001 | 0.695 |
| mg_level | 0.773 | 1 | 0.773 | 2.89 | 0.0907 | 0.017 |
| cultivar x mg_level | 1.525 | 2 | 0.763 | 2.86 | 0.0603 | 0.032 |
| Residual | 45.939 | 172 | 0.267 | | | |

Rank-based ANOVA (robustness): cultivar p < 0.001; magnesium p = 0.073; interaction F = 4.84, p = 0.009.

| Cultivar | Magnesium | n | Mean flavanoids | SD | 95% CI of mean |
|---|---|---|---|---|---|
| Cultivar 1 | Low Mg | 16 | 2.749 | 0.399 | [2.536, 2.961] |
| Cultivar 1 | High Mg | 43 | 3.069 | 0.364 | [2.957, 3.181] |
| Cultivar 2 | Low Mg | 52 | 2.116 | 0.608 | [1.947, 2.285] |
| Cultivar 2 | High Mg | 19 | 1.985 | 0.935 | [1.534, 2.436] |
| Cultivar 3 | Low Mg | 28 | 0.680 | 0.220 | [0.594, 0.765] |
| Cultivar 3 | High Mg | 20 | 0.924 | 0.328 | [0.770, 1.078] |

* **Cultivar:** strongly significant (partial eta-squared = 0.70).
* **Magnesium main effect:** not significant (p = 0.091).
* **Interaction:** not significant in the classical test (p = 0.060) but significant in the rank-based test (p = 0.009). Residuals are not normal (p < 0.001) and cell variances are unequal (Levene p < 0.001), so this is borderline and method-dependent.
* **Simple effects (High minus Low Mg):**

| Cultivar | Difference | 95% CI | Welch p | Bonferroni p |
|---|---|---|---|---|
| Cultivar 1 | +0.32 | [0.09, 0.56] | 0.0096 | 0.0287 |
| Cultivar 2 | -0.13 | [-0.61, 0.34] | 0.5746 | 1.0000 |
| Cultivar 3 | +0.24 | [0.07, 0.42] | 0.0069 | 0.0206 |

* **Tukey HSD on the six cells:** 12 of 15 pairs differ, all of them between different cultivars; none of the three same-cultivar magnesium contrasts is significant after the family-wise correction.

![Figure 7. Two-way ANOVA: interaction plot, distributions, residual check](../figures/fig7_twoway_anova.png){width=6.3in}

![Figure 8. Tukey HSD across the six cells](../figures/fig8_tukey_twoway_cells.png){width=4.8in}

# 5. Findings

1. **Cultivar drives the chemistry.** Alcohol, proline and flavanoids differ strongly between cultivars (Hedges' g about 2.9 for alcohol and 3.1 for proline between Cultivars 1 and 2; eta-squared 0.70 for proline). Every parametric and non-parametric test agrees.
2. **Test choice matters only where assumptions fail.** For alcohol (both groups normal) the t-test and Mann-Whitney agree closely; for proline (skewed, unequal variances) the rank-based and robust tests confirm the t-test result, so the conclusion is not an artefact of assumptions.
3. **All three cultivars differ in proline.** Tukey HSD: Cultivar 1 is about 596 above Cultivar 2 and about 486 above Cultivar 3; Cultivar 2 is about 110 below Cultivar 3 (the smallest gap, still significant, adjusted p = 0.002).
4. **Magnesium has a small, uncertain association with flavanoids.** There is no significant main effect, the interaction is borderline, and simple effects suggest a modest increase with higher magnesium in Cultivars 1 and 3 but not Cultivar 2. This is an exploratory pattern, not a firm conclusion.

# 6. Limitations

* Observational data from one region and period; results describe these wines, not wines in general.
* Several samples are non-normal and some variances are unequal, so robust and rank-based checks are reported next to the classical tests.
* Magnesium was dichotomised at the median, which discards information and unbalances the design.
* alpha = 0.05 was used per test with no overall correction across sections, except where stated (Tukey, Holm, Bonferroni).
* The notebook was executed with a small custom runner because Jupyter is not installed in this environment; outputs are embedded and the notebook opens normally in Jupyter, VS Code or Colab, where Run All reproduces them.

# 7. Reproducibility

Seed 20261109; exact package versions in `requirements.lock`; results saved to `results/results.json` and `results/all_tests_summary.csv`; a consistency check at the end of the notebook fails if the written claims stop matching the computed results.

# 8. Submission

The brief asks for one public link. Upload `notebooks/Task03_Statistical_Analysis.ipynb` (for example to a public GitHub repository, or Google Colab with link sharing on) and submit that URL. I have no way to publish a link from this session.
