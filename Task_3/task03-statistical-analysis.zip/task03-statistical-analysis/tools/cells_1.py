CELLS_1 = []
M = lambda s: CELLS_1.append(("markdown", s))
C = lambda s: CELLS_1.append(("code", s))

M(r'''
# Task 03: Advanced Statistical Analysis & Hypothesis Testing
### Chemical profiles of Italian wines from three cultivars: parametric and non-parametric inference, ANOVA and Tukey HSD

**Goal (from the task brief):** perform rigorous inferential statistics on a scientific/business dataset, conducting parametric and non-parametric hypothesis tests and ANOVA analysis.

## 0. Requirement checklist (every point of the brief)

| # | Requirement in the brief | Where it is done in this notebook |
|---|---|---|
| 1 | Shapiro-Wilk normality tests on sample distributions | Section 4.1 (12 samples: 4 variables x 3 cultivars) and residual checks in 6.2 and 7.3 |
| 2 | Kolmogorov-Smirnov normality tests on sample distributions | Section 4.2 (plain KS and Lilliefors-corrected KS) |
| 3 | Two-sample t-tests (significance at p < 0.05) | Section 5 (Student and Welch) |
| 4 | Mann-Whitney U tests (significance at p < 0.05) | Section 5 |
| 5 | One-Way ANOVA | Section 6 |
| 6 | Two-Way ANOVA | Section 7 |
| 7 | Tukey HSD post-hoc analysis across multiple groups | Section 6.4 (3 groups) and Section 7.5 (6 cells) |
| 8 | Null and alternative hypotheses documented in markdown | A hypothesis block before every test family (Sections 4 to 7) |
| 9 | Confidence intervals documented | 95% CIs for mean differences, group means, Hodges-Lehmann shifts, effect sizes and Tukey differences |
| 10 | Distribution plots | Figures in Sections 3, 4, 5, 6 and 7 |
| 11 | Findings | Section 8 (computed summary) and Section 9 (written findings) |
| 12 | Expected proof: Jupyter Notebook (.ipynb) with tests, plots and findings | This file, with all outputs embedded |

**Significance level:** alpha = 0.05 (two-sided) for every test, as the brief specifies p < 0.05. Where several tests answer one family of questions, adjusted p-values are also shown.
''')

M(r'''
## 1. Dataset and study design

* **Dataset:** the UCI *Wine* data (Forina et al., 1991; PARVUS). 178 wines grown in one Italian region from **three cultivars**, each described by 13 laboratory chemical measurements. It is a scientific dataset with a natural grouping factor, which is what ANOVA needs. It is bundled with scikit-learn (`load_wine`), so the notebook runs offline.
* **Units of analysis:** one wine sample (independent observations, one row each).
* **Factors:** *cultivar* (3 levels) and, for the two-way design, *magnesium level* (Low = at or below the sample median, High = above it).
* **Response variables used:**

| Variable | Meaning | Used for |
|---|---|---|
| `alcohol` | alcohol content (% vol.) | normality; two-sample comparison 1 |
| `proline` | proline amino-acid concentration (mg/L), right-skewed | normality; two-sample comparison 2; one-way ANOVA |
| `flavanoids` | flavanoid phenols (mg/L) | normality; two-way ANOVA |
| `color_intensity` | colour intensity | normality |

**Design decisions made before looking at any test result:** which variables and comparisons are analysed is fixed here. Both parametric and non-parametric tests are always run and reported; the rule used to decide which is the primary result is stated in Section 5.
''')

C(r'''
import json, math, platform, warnings
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.datasets import load_wine
from IPython.display import display, Markdown

SEED = 20261109
ALPHA = 0.05
rng = np.random.default_rng(SEED)
FIG_DIR = Path("..") / "figures"; FIG_DIR.mkdir(exist_ok=True)
RES_DIR = Path("..") / "results"; RES_DIR.mkdir(exist_ok=True)

COLORS = {"Cultivar 1": "#1b9e77", "Cultivar 2": "#d95f02", "Cultivar 3": "#7570b3"}
plt.rcParams.update({"figure.dpi": 100, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": 0.25, "font.size": 10, "axes.titlesize": 11})
RESULTS = {}    # everything the written findings rely on is collected here and saved to results/

print("Python", platform.python_version(), "| numpy", np.__version__, "| scipy", scipy.__version__,
      "| pandas", pd.__version__, "| matplotlib", matplotlib.__version__, "| seaborn", sns.__version__)
print("Seed", SEED, "| alpha", ALPHA)
''')

C(r'''
wine = load_wine(as_frame=True)
df = wine.frame.copy()
df["cultivar"] = df["target"].map({0: "Cultivar 1", 1: "Cultivar 2", 2: "Cultivar 3"})
CULT = ["Cultivar 1", "Cultivar 2", "Cultivar 3"]
VARS = ["alcohol", "flavanoids", "proline", "color_intensity"]

print("Rows x columns:", df.shape, "| missing values:", int(df.isna().sum().sum()),
      "| duplicate rows:", int(df.duplicated().sum()))
display(df["cultivar"].value_counts().reindex(CULT).rename("n wines").to_frame())
summary = df.groupby("cultivar")[VARS].agg(["count", "mean", "std"]).round(2)
summary
''')

M(r'''
## 2. Helper functions and validation of the custom implementations

`scipy` supplies Shapiro-Wilk, KS, t, Mann-Whitney, one-way F, Kruskal-Wallis and Tukey HSD. `statsmodels` is not installed here, so the pieces scipy does not provide (Lilliefors-corrected KS, Welch ANOVA, Games-Howell, Hodges-Lehmann shift, two-way ANOVA) are written below and **validated against closed-form results before they are used**.
''')

C(r'''
def fmt_p(p):
    return "p < 0.001" if p < 0.001 else f"p = {p:.3f}"

def holm(pvals):
    p = np.asarray(pvals, float); m = len(p); adj = np.empty(m); run = 0.0
    for rank, i in enumerate(np.argsort(p)):
        run = max(run, (m - rank) * p[i]); adj[i] = min(1.0, run)
    return adj

# ---------- normality ----------
_LF = {}
def lilliefors_null(n, B=10000):
    # Monte-Carlo null distribution of the KS statistic when mean and SD are estimated from the sample
    if n not in _LF:
        r = np.random.default_rng(SEED + n)
        x = r.standard_normal((B, n))
        z = np.sort((x - x.mean(1, keepdims=True)) / x.std(1, ddof=1, keepdims=True), axis=1)
        F = stats.norm.cdf(z); i = np.arange(1, n + 1)
        _LF[n] = np.maximum((i / n - F).max(1), (F - (i - 1) / n).max(1))
    return _LF[n]

def ks_normal(x):
    x = np.asarray(x, float); z = (x - x.mean()) / x.std(ddof=1)
    r = stats.kstest(z, "norm"); null = lilliefors_null(len(x))
    return r.statistic, r.pvalue, (1 + (null >= r.statistic).sum()) / (len(null) + 1)

# ---------- two-sample ----------
def student_ci(a, b, alpha=ALPHA):
    na, nb = len(a), len(b); sp2 = ((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2)
    se = math.sqrt(sp2 * (1 / na + 1 / nb)); d = a.mean() - b.mean(); df_ = na + nb - 2
    t = stats.t.ppf(1 - alpha / 2, df_); return d, d - t * se, d + t * se, df_

def welch_ci(a, b, alpha=ALPHA):
    na, nb = len(a), len(b); va, vb = a.var(ddof=1) / na, b.var(ddof=1) / nb
    df_ = (va + vb) ** 2 / (va ** 2 / (na - 1) + vb ** 2 / (nb - 1)); d = a.mean() - b.mean()
    t = stats.t.ppf(1 - alpha / 2, df_); se = math.sqrt(va + vb); return d, d - t * se, d + t * se, df_

def hedges_g_ci(a, b, alpha=ALPHA):
    n1, n2 = len(a), len(b)
    sp = math.sqrt(((n1 - 1) * a.var(ddof=1) + (n2 - 1) * b.var(ddof=1)) / (n1 + n2 - 2))
    g = (a.mean() - b.mean()) / sp * (1 - 3 / (4 * (n1 + n2) - 9))
    se = math.sqrt((n1 + n2) / (n1 * n2) + g ** 2 / (2 * (n1 + n2))); z = stats.norm.ppf(1 - alpha / 2)
    return g, g - z * se, g + z * se

def hodges_lehmann(a, b, B=2000, alpha=ALPHA, r=None):
    r = r or np.random.default_rng(SEED)
    est = np.median((a[:, None] - b[None, :]))
    boots = np.array([np.median(r.choice(a, len(a))[:, None] - r.choice(b, len(b))[None, :]) for _ in range(B)])
    return est, *np.quantile(boots, [alpha / 2, 1 - alpha / 2])

# ---------- one-way ----------
def anova_oneway(groups):
    k = len(groups); n = sum(len(g) for g in groups); gm = np.concatenate(groups).mean()
    ssb = sum(len(g) * (g.mean() - gm) ** 2 for g in groups); ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
    dfb, dfw = k - 1, n - k; msw = ssw / dfw; F = (ssb / dfb) / msw
    return {"ssb": ssb, "ssw": ssw, "sst": ssb + ssw, "dfb": dfb, "dfw": dfw, "msb": ssb / dfb, "msw": msw, "F": F,
            "p": stats.f.sf(F, dfb, dfw), "eta2": ssb / (ssb + ssw), "omega2": (ssb - dfb * msw) / (ssb + ssw + msw)}

def welch_anova(groups):
    k = len(groups); n = np.array([len(g) for g in groups]); m = np.array([g.mean() for g in groups])
    v = np.array([g.var(ddof=1) for g in groups]); w = n / v; W = w.sum(); mw = (w * m).sum() / W
    lam = (((1 - w / W) ** 2) / (n - 1)).sum()
    F = ((w * (m - mw) ** 2).sum() / (k - 1)) / (1 + 2 * (k - 2) / (k ** 2 - 1) * lam)
    df2 = (k ** 2 - 1) / (3 * lam); return F, k - 1, df2, stats.f.sf(F, k - 1, df2)

def games_howell(groups, names):
    rows = []; k = len(groups)
    for i in range(k):
        for j in range(i + 1, k):
            a, b = groups[i], groups[j]; va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
            d = a.mean() - b.mean(); se = math.sqrt(va + vb); df_ = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
            q = abs(d) / math.sqrt((va + vb) / 2); p = stats.studentized_range.sf(q, k, df_)
            crit = stats.studentized_range.ppf(1 - ALPHA, k, df_) / math.sqrt(2)
            rows.append({"comparison": f"{names[i]} - {names[j]}", "diff": d, "ci_low": d - crit * se, "ci_high": d + crit * se, "p": p})
    return pd.DataFrame(rows)

def tukey_table(groups, names):
    res = stats.tukey_hsd(*groups); ci = res.confidence_interval(confidence_level=1 - ALPHA); rows = []
    for i in range(len(groups)):
        for j in range(i + 1, len(groups)):
            rows.append({"comparison": f"{names[i]} - {names[j]}", "diff": res.statistic[i, j], "ci_low": ci.low[i, j],
                         "ci_high": ci.high[i, j], "p_adj": res.pvalue[i, j], "significant": bool(res.pvalue[i, j] < ALPHA)})
    return pd.DataFrame(rows)

# ---------- two-way (effect-coded least squares; Type II and Type III sums of squares) ----------
def effect_cols(x, levels):
    last = (x == levels[-1]).to_numpy(float)
    return np.column_stack([(x == lv).to_numpy(float) - last for lv in levels[:-1]])

def _rss(X, y):
    coef, *_ = np.linalg.lstsq(X, y, rcond=None); r = y - X @ coef; return float(r @ r), r

def anova2(data, y, A, B, LA, LB):
    yv = data[y].to_numpy(float); n = len(yv); one = np.ones((n, 1))
    XA, XB = effect_cols(data[A], LA), effect_cols(data[B], LB)
    XAB = np.column_stack([XA[:, i] * XB[:, j] for i in range(XA.shape[1]) for j in range(XB.shape[1])])
    rss_full, resid = _rss(np.hstack([one, XA, XB, XAB]), yv); dfe = n - (1 + XA.shape[1] + XB.shape[1] + XAB.shape[1]); mse = rss_full / dfe
    rss_ab, _ = _rss(np.hstack([one, XA, XB]), yv); rss_b, _ = _rss(np.hstack([one, XB]), yv); rss_a, _ = _rss(np.hstack([one, XA]), yv)
    rss_noA, _ = _rss(np.hstack([one, XB, XAB]), yv); rss_noB, _ = _rss(np.hstack([one, XA, XAB]), yv)
    dfs = {A: XA.shape[1], B: XB.shape[1], f"{A} x {B}": XAB.shape[1]}
    def table(ss):
        rows = []
        for term, s in ss.items():
            F = (s / dfs[term]) / mse; rows.append({"Source": term, "SS": s, "df": dfs[term], "MS": s / dfs[term], "F": F,
                                                   "p": stats.f.sf(F, dfs[term], dfe), "partial_eta2": s / (s + rss_full)})
        rows.append({"Source": "Residual", "SS": rss_full, "df": dfe, "MS": mse, "F": np.nan, "p": np.nan, "partial_eta2": np.nan})
        return pd.DataFrame(rows)
    t3 = table({A: rss_noA - rss_full, B: rss_noB - rss_full, f"{A} x {B}": rss_ab - rss_full})
    t2 = table({A: rss_b - rss_ab, B: rss_a - rss_ab, f"{A} x {B}": rss_ab - rss_full})
    return {"type3": t3, "type2": t2, "resid": resid, "mse": mse, "dfe": dfe, "sst": float(((yv - yv.mean()) ** 2).sum())}
''')

C(r'''
# ---- Validation 1: Lilliefors p-values behave (uniform under a true normal null) ----
r0 = np.random.default_rng(1)
pv = np.array([ks_normal(r0.normal(size=40))[2] for _ in range(400)])
print(f"Lilliefors-KS false-positive rate on true-normal data: {(pv < ALPHA).mean():.3f} (nominal 0.05)")
pn = np.array([ks_normal(r0.normal(size=40))[1] for _ in range(400)])
print(f"Plain KS (estimated parameters, naive p) false-positive rate: {(pn < ALPHA).mean():.3f}  <- conservative, as theory predicts")

# ---- Validation 2: Welch t CI equals scipy's; Welch ANOVA with k=2 equals Welch t squared ----
a, b = r0.normal(10, 2, 35), r0.normal(11, 4, 50)
res = stats.ttest_ind(a, b, equal_var=False); ci = res.confidence_interval(0.95); d, lo, hi, dfw = welch_ci(a, b)
assert np.allclose([lo, hi], [ci.low, ci.high]) and np.isclose(dfw, res.df)
F, d1, d2, pF = welch_anova([a, b]); assert np.isclose(F, res.statistic ** 2) and np.isclose(pF, res.pvalue)
print("Welch CI matches scipy; Welch ANOVA (k=2) F equals Welch t^2 with identical p-value: OK")

# ---- Validation 3: hand-built one-way ANOVA equals scipy.f_oneway; Tukey p matches studentized-range formula ----
g = [r0.normal(m, 3, n) for m, n in [(5, 20), (7, 25), (9, 30)]]
o = anova_oneway(g); fo = stats.f_oneway(*g); assert np.isclose(o["F"], fo.statistic) and np.isclose(o["p"], fo.pvalue)
tk = tukey_table(g, ["A", "B", "C"]).iloc[0]
q = abs(g[0].mean() - g[1].mean()) / math.sqrt(o["msw"] / 2 * (1 / len(g[0]) + 1 / len(g[1])))
assert np.isclose(tk["p_adj"], stats.studentized_range.sf(q, 3, o["dfw"]))
print("One-way F equals scipy.f_oneway; Tukey p equals the Tukey-Kramer studentized-range formula: OK")

# ---- Validation 4: two-way ANOVA against closed-form sums of squares on a balanced design ----
rows = [(a_, b_, r0.normal(10 + 2 * ia + 3 * ib + 1.5 * ia * ib, 2)) for ia, a_ in enumerate(["a1", "a2", "a3"])
        for ib, b_ in enumerate(["b1", "b2"]) for _ in range(12)]
bal = pd.DataFrame(rows, columns=["A", "B", "y"]); out = anova2(bal, "y", "A", "B", ["a1", "a2", "a3"], ["b1", "b2"])
gm = bal.y.mean(); nc = 12
ssA = nc * 2 * ((bal.groupby("A").y.mean() - gm) ** 2).sum(); ssB = nc * 3 * ((bal.groupby("B").y.mean() - gm) ** 2).sum()
cell = bal.groupby(["A", "B"]).y.mean(); mA = bal.groupby("A").y.mean(); mB = bal.groupby("B").y.mean()
ssAB = nc * sum((cell[(i, j)] - mA[i] - mB[j] + gm) ** 2 for i in mA.index for j in mB.index)
t3 = out["type3"].set_index("Source")
assert np.isclose(t3.loc["A", "SS"], ssA) and np.isclose(t3.loc["B", "SS"], ssB) and np.isclose(t3.loc["A x B", "SS"], ssAB)
assert np.allclose(out["type2"]["SS"], out["type3"]["SS"])                       # balanced design: Type II == Type III
assert np.isclose(t3["SS"].sum(), out["sst"])                                     # balanced: SS partition is exact
print("Two-way ANOVA SS match closed-form formulas; Type II equals Type III; partition adds to total SS: OK")
''')
